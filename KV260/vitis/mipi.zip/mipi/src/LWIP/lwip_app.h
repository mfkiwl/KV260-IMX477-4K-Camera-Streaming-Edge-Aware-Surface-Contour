#ifndef LWIP_APP_H
#define LWIP_APP_H

/* Returns 0 on start, 1 if already started, or a negative value on error. */
int lwip_stream_start(void);

/* Call from the foreground, including while waiting for UART input. */
void lwip_stream_poll(void);

#endif
