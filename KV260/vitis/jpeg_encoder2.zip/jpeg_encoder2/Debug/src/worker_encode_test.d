src/worker_encode_test.o src/worker_encode_test.o: \
 ../src/worker_encode_test.c \
 R:\KV260\third_party\libjpeg-turbo-3.0.4/jpeglib.h \
 R:\KV260\jpeg_benchmark\build-kv260-arm64-notls/jconfig.h \
 R:\KV260\third_party\libjpeg-turbo-3.0.4/jmorecfg.h \
 R:\KV260\third_party\libjpeg-turbo-3.0.4/jerror.h \
 R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xtime_l.h \
 R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xil_types.h \
 R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xparameters.h \
 R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xparameters_ps.h
R:\KV260\third_party\libjpeg-turbo-3.0.4/jpeglib.h:
R:\KV260\jpeg_benchmark\build-kv260-arm64-notls/jconfig.h:
R:\KV260\third_party\libjpeg-turbo-3.0.4/jmorecfg.h:
R:\KV260\third_party\libjpeg-turbo-3.0.4/jerror.h:
R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xtime_l.h:
R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xil_types.h:
R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xparameters.h:
R:/KV260/vitis/kv260_video_wrapper/export/kv260_video_wrapper/sw/kv260_video_wrapper/jpeg_worker2/bspinclude/include/xparameters_ps.h:
