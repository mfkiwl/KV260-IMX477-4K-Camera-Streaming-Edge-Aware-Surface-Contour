################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -ljpeg -Wl,--start-group,-lxil,-lgcc,-lc,--end-group

