/*
   MODIFICATION HISTORY:
   Ver   Who Date     Changes
   ----- -------- -------- -----------------------------------------------
   1.0	 Sakinder 06/01/22 Initial Release
   1.3   Sakinder 06/14/22 Added IMX477 Camera functions.
   -----------------------------------------------------------------------
*/
#include "imx477.h"
#include <xil_types.h>
#include <stdio.h>
#include <xstatus.h>
#include <xil_io.h>
#include "xiicps.h"
#include "xparameters.h"
#include "sleep.h"
#include <xil_printf.h>
#include "../../config.h"
#include "../I2c_transections.h"
#include "../init_camera.h"
#include "../imx_registers.h"
#define IIC_IMX477_ADDR  	        0x9A
////////////////////////////////////////////////////
/* Chip ID */
#define IMX477_REG_CHIP_ID		    0x0016
#define IMX477_CHIP_ID			    0x0477
#define IMX477_MODE_STANDBY		    0x00
#define IMX477_MODE_STREAMING		0x01
#define IMX477_REG_ORIENTATION		0x101
#define IMX477_XCLK_FREQ		    24000000
#define IMX477_DEFAULT_LINK_FREQ	450000000
/* Pixel rate is fixed at 840MHz for all the modes */
#define IMX477_PIXEL_RATE		    840000000
/* V_TIMING internal */
#define IMX477_REG_FRAME_LENGTH		REG_FRAME_LEN_MSB
#define IMX477_FRAME_LENGTH_MAX		0xffdc
/* Exposure control */
#define IMX477_REG_EXPOSURE		    REG_COARSE_INTEGRATION_TIME_MSB
#define IMX477_EXPOSURE_OFFSET		22
#define IMX477_EXPOSURE_MIN		    20
#define IMX477_EXPOSURE_STEP		1
#define IMX477_EXPOSURE_DEFAULT		0x640
#define IMX477_EXPOSURE_MAX		(IMX477_FRAME_LENGTH_MAX - \
					 IMX477_EXPOSURE_OFFSET)
/* Analog gain control */
#define IMX477_REG_ANALOG_GAIN		REG_ANA_GLOBAL_GAIN_U
#define IMX477_ANA_GAIN_MIN		    0
#define IMX477_ANA_GAIN_MAX		    978
#define IMX477_ANA_GAIN_STEP		1
#define IMX477_ANA_GAIN_DEFAULT		0x0
/* Digital gain control */
#define IMX477_REG_DIGITAL_GAIN		0x020e
#define IMX477_DGTL_GAIN_MIN		0x0100
#define IMX477_DGTL_GAIN_MAX		0xffff
#define IMX477_DGTL_GAIN_DEFAULT	0x0100
#define IMX477_DGTL_GAIN_STEP		1
/* Test Pattern Control */
#define IMX477_REG_TEST_PATTERN		    0x0600
#define IMX477_TEST_PATTERN_DISABLE	    0
#define IMX477_TEST_PATTERN_SOLID_COLOR	1
#define IMX477_TEST_PATTERN_COLOR_BARS	2
#define IMX477_TEST_PATTERN_GREY_COLOR	3
#define IMX477_TEST_PATTERN_PN9		    4
/* Test pattern colour components */
#define IMX477_REG_TEST_PATTERN_R	    0x0602
#define IMX477_REG_TEST_PATTERN_GR	    0x0604
#define IMX477_REG_TEST_PATTERN_B	    0x0606
#define IMX477_REG_TEST_PATTERN_GB	    0x0608
#define IMX477_TEST_PATTERN_COLOUR_MIN	0
#define IMX477_TEST_PATTERN_COLOUR_MAX	0x0fff
#define IMX477_TEST_PATTERN_COLOUR_STEP	1
#define IMX477_TEST_PATTERN_R_DEFAULT	IMX477_TEST_PATTERN_COLOUR_MAX
#define IMX477_TEST_PATTERN_GR_DEFAULT	0
#define IMX477_TEST_PATTERN_B_DEFAULT	0
#define IMX477_TEST_PATTERN_GB_DEFAULT	0
/* Embedded metadata stream structure */
#define IMX477_EMBEDDED_LINE_WIDTH 16384
#define IMX477_NUM_EMBEDDED_LINES 1
#define IMX477_ANA_GLOBAL_GAIN_U	    REG_ANA_GLOBAL_GAIN_U
#define IMX477_ANA_GLOBAL_GAIN_L	    0x0205
#define IMX477_DIG_GLOBAL_GAIN	        0x3FF9
#define IMX477_DIG_GAIN_GR_U	        0x020E
#define IMX477_DIG_GAIN_GR_L	        0x020F
#define IMX477_DIG_GAIN_R_U	            0x0210
#define IMX477_DIG_GAIN_R_L	            0x0211
#define IMX477_DIG_GAIN_B_U	            0x0212
#define IMX477_DIG_GAIN_B_L	            0x0213
#define IMX477_DIG_GAIN_GB_U	        0x0214
#define IMX477_DIG_GAIN_GB_L	        0x0215
#define REG_DLY  SEQUENCE_WAIT_MS
struct reginfo ONETIME_INIT_REG_SET1[]={
	{REG_EXCK_FREQ_MSB, 0x18},
	{REG_EXCK_FREQ_LSB, 0x00},
	{REG_TEMP_SENS_CTL, 0x01},
	{REG_FRAME_BLANKSTOP_CTRL, 0x01},
	{IMX477_REG_ORIENTATION, 0xff},
	{0xe07a, 0x01},
	{REG_DPHY_CTRL, 0x02},
	{0x4ae9, 0x18},
	{0x4aea, 0x08},
	{0xf61c, 0x04},
	{0xf61e, 0x04},
	{0x4ae9, 0x21},
	{0x4aea, 0x80},
	{REG_PD_AREA_WIDTH_MSB, 0x1f},
	{REG_PD_AREA_WIDTH_LSB, 0xff},
	{REG_PD_AREA_HEIGHT_MSB, 0x1f},
	{REG_PD_AREA_HEIGHT_LSB, 0xff},
	{0x55d4, 0x00},
	{0x55d5, 0x00},
	{0x55d6, 0x07},
	{0x55d7, 0xff},
	{0x55e8, 0x07},
	{0x55e9, 0xff},
	{0x55ea, 0x00},
	{0x55eb, 0x00},
	{0x574c, 0x07},
	{0x574d, 0xff},
	{0x574e, 0x00},
	{0x574f, 0x00},
	{0x5754, 0x00},
	{0x5755, 0x00},
	{0x5756, 0x07},
	{0x5757, 0xff},
	{0x5973, 0x04},
	{0x5974, 0x01},
	{0x5d13, 0xc3},
	{0x5d14, 0x58},
	{0x5d15, 0xa3},
	{0x5d16, 0x1d},
	{0x5d17, 0x65},
	{0x5d18, 0x8c},
	{0x5d1a, 0x06},
	{0x5d1b, 0xa9},
	{0x5d1c, 0x45},
	{0x5d1d, 0x3a},
	{0x5d1e, 0xab},
	{0x5d1f, 0x15},
	{0x5d21, 0x0e},
	{0x5d22, 0x52},
	{0x5d23, 0xaa},
	{0x5d24, 0x7d},
	{0x5d25, 0x57},
	{0x5d26, 0xa8},
	{0x5d37, 0x5a},
	{0x5d38, 0x5a},
	{0x5d77, 0x7f},
	{0x7b75, 0x0e},
	{0x7b76, 0x0b},
	{0x7b77, 0x08},
	{0x7b78, 0x0a},
	{0x7b79, 0x47},
	{0x7b7c, 0x00},
	{0x7b7d, 0x00},
	{0x8d1f, 0x00},
	{0x8d27, 0x00},
	{0x9004, 0x03},
	{0x9200, 0x50},
	{0x9201, 0x6c},
	{0x9202, 0x71},
	{0x9203, 0x00},
	{0x9204, 0x71},
	{0x9205, 0x01},
	{0x9371, 0x6a},
	{0x9373, 0x6a},
	{0x9375, 0x64},
	{0x991a, 0x00},
	{0x996b, 0x8c},
	{0x996c, 0x64},
	{0x996d, 0x50},
	{0x9a4c, 0x0d},
	{0x9a4d, 0x0d},
	{0xa001, 0x0a},
	{0xa003, 0x0a},
	{0xa005, 0x0a},
	{0xa006, 0x01},
	{0xa007, 0xc0},
	{0xa009, 0xc0},
	{0x3d8a, 0x01},
	{0x4421, 0x04},
	{0x7b3b, 0x01},
	{0x7b4c, 0x00},
	{0x9905, 0x00},
	{0x9907, 0x00},
	{0x9909, 0x00},
	{0x990b, 0x00},
	{0x9944, 0x3c},
	{0x9947, 0x3c},
	{0x994a, 0x8c},
	{0x994b, 0x50},
	{0x994c, 0x1b},
	{0x994d, 0x8c},
	{0x994e, 0x50},
	{0x994f, 0x1b},
	{0x9950, 0x8c},
	{0x9951, 0x1b},
	{0x9952, 0x0a},
	{0x9953, 0x8c},
	{0x9954, 0x1b},
	{0x9955, 0x0a},
	{0x9a13, 0x04},
	{0x9a14, 0x04},
	{0x9a19, 0x00},
	{0x9a1c, 0x04},
	{0x9a1d, 0x04},
	{0x9a26, 0x05},
	{0x9a27, 0x05},
	{0x9a2c, 0x01},
	{0x9a2d, 0x03},
	{0x9a2f, 0x05},
	{0x9a30, 0x05},
	{0x9a41, 0x00},
	{0x9a46, 0x00},
	{0x9a47, 0x00},
	{0x9c17, 0x35},
	{0x9c1d, 0x31},
	{0x9c29, 0x50},
	{0x9c3b, 0x2f},
	{0x9c41, 0x6b},
	{0x9c47, 0x2d},
	{0x9c4d, 0x40},
	{0x9c6b, 0x00},
	{0x9c71, 0xc8},
	{0x9c73, 0x32},
	{0x9c75, 0x04},
	{0x9c7d, 0x2d},
	{0x9c83, 0x40},
	{0x9c94, 0x3f},
	{0x9c95, 0x3f},
	{0x9c96, 0x3f},
	{0x9c97, 0x00},
	{0x9c98, 0x00},
	{0x9c99, 0x00},
	{0x9c9a, 0x3f},
	{0x9c9b, 0x3f},
	{0x9c9c, 0x3f},
	{0x9ca0, 0x0f},
	{0x9ca1, 0x0f},
	{0x9ca2, 0x0f},
	{0x9ca3, 0x00},
	{0x9ca4, 0x00},
	{0x9ca5, 0x00},
	{0x9ca6, 0x1e},
	{0x9ca7, 0x1e},
	{0x9ca8, 0x1e},
	{0x9ca9, 0x00},
	{0x9caa, 0x00},
	{0x9cab, 0x00},
	{0x9cac, 0x09},
	{0x9cad, 0x09},
	{0x9cae, 0x09},
	{0x9cbd, 0x50},
	{0x9cbf, 0x50},
	{0x9cc1, 0x50},
	{0x9cc3, 0x40},
	{0x9cc5, 0x40},
	{0x9cc7, 0x40},
	{0x9cc9, 0x0a},
	{0x9ccb, 0x0a},
	{0x9ccd, 0x0a},
	{0x9d17, 0x35},
	{0x9d1d, 0x31},
	{0x9d29, 0x50},
	{0x9d3b, 0x2f},
	{0x9d41, 0x6b},
	{0x9d47, 0x42},
	{0x9d4d, 0x5a},
	{0x9d6b, 0x00},
	{0x9d71, 0xc8},
	{0x9d73, 0x32},
	{0x9d75, 0x04},
	{0x9d7d, 0x42},
	{0x9d83, 0x5a},
	{0x9d94, 0x3f},
	{0x9d95, 0x3f},
	{0x9d96, 0x3f},
	{0x9d97, 0x00},
	{0x9d98, 0x00},
	{0x9d99, 0x00},
	{0x9d9a, 0x3f},
	{0x9d9b, 0x3f},
	{0x9d9c, 0x3f},
	{0x9d9d, 0x1f},
	{0x9d9e, 0x1f},
	{0x9d9f, 0x1f},
	{0x9da0, 0x0f},
	{0x9da1, 0x0f},
	{0x9da2, 0x0f},
	{0x9da3, 0x00},
	{0x9da4, 0x00},
	{0x9da5, 0x00},
	{0x9da6, 0x1e},
	{0x9da7, 0x1e},
	{0x9da8, 0x1e},
	{0x9da9, 0x00},
	{0x9daa, 0x00},
	{0x9dab, 0x00},
	{0x9dac, 0x09},
	{0x9dad, 0x09},
	{0x9dae, 0x09},
	{0x9dc9, 0x0a},
	{0x9dcb, 0x0a},
	{0x9dcd, 0x0a},
	{0x9e17, 0x35},
	{0x9e1d, 0x31},
	{0x9e29, 0x50},
	{0x9e3b, 0x2f},
	{0x9e41, 0x6b},
	{0x9e47, 0x2d},
	{0x9e4d, 0x40},
	{0x9e6b, 0x00},
	{0x9e71, 0xc8},
	{0x9e73, 0x32},
	{0x9e75, 0x04},
	{0x9e94, 0x0f},
	{0x9e95, 0x0f},
	{0x9e96, 0x0f},
	{0x9e97, 0x00},
	{0x9e98, 0x00},
	{0x9e99, 0x00},
	{0x9ea0, 0x0f},
	{0x9ea1, 0x0f},
	{0x9ea2, 0x0f},
	{0x9ea3, 0x00},
	{0x9ea4, 0x00},
	{0x9ea5, 0x00},
	{0x9ea6, 0x3f},
	{0x9ea7, 0x3f},
	{0x9ea8, 0x3f},
	{0x9ea9, 0x00},
	{0x9eaa, 0x00},
	{0x9eab, 0x00},
	{0x9eac, 0x09},
	{0x9ead, 0x09},
	{0x9eae, 0x09},
	{0x9ec9, 0x0a},
	{0x9ecb, 0x0a},
	{0x9ecd, 0x0a},
	{0x9f17, 0x35},
	{0x9f1d, 0x31},
	{0x9f29, 0x50},
	{0x9f3b, 0x2f},
	{0x9f41, 0x6b},
	{0x9f47, 0x42},
	{0x9f4d, 0x5a},
	{0x9f6b, 0x00},
	{0x9f71, 0xc8},
	{0x9f73, 0x32},
	{0x9f75, 0x04},
	{0x9f94, 0x0f},
	{0x9f95, 0x0f},
	{0x9f96, 0x0f},
	{0x9f97, 0x00},
	{0x9f98, 0x00},
	{0x9f99, 0x00},
	{0x9f9a, 0x2f},
	{0x9f9b, 0x2f},
	{0x9f9c, 0x2f},
	{0x9f9d, 0x00},
	{0x9f9e, 0x00},
	{0x9f9f, 0x00},
	{0x9fa0, 0x0f},
	{0x9fa1, 0x0f},
	{0x9fa2, 0x0f},
	{0x9fa3, 0x00},
	{0x9fa4, 0x00},
	{0x9fa5, 0x00},
	{0x9fa6, 0x1e},
	{0x9fa7, 0x1e},
	{0x9fa8, 0x1e},
	{0x9fa9, 0x00},
	{0x9faa, 0x00},
	{0x9fab, 0x00},
	{0x9fac, 0x09},
	{0x9fad, 0x09},
	{0x9fae, 0x09},
	{0x9fc9, 0x0a},
	{0x9fcb, 0x0a},
	{0x9fcd, 0x0a},
	{0xa14b, 0xff},
	{0xa151, 0x0c},
	{0xa153, 0x50},
	{0xa155, 0x02},
	{0xa157, 0x00},
	{0xa1ad, 0xff},
	{0xa1b3, 0x0c},
	{0xa1b5, 0x50},
	{0xa1b9, 0x00},
	{0xa24b, 0xff},
	{0xa257, 0x00},
	{0xa2ad, 0xff},
	{0xa2b9, 0x00},
	{0xb21f, 0x04},
	{0xb35c, 0x00},
	{0xb35e, 0x08},
	{REG_FRAME_LENGTH_CTRL, 0x00},
	{REG_EBD_SIZE_V, 0x02},
	{REG_DPGA_GLOBEL_GAIN, 0x40},
	/* Signaling mode setting */
	{0x0111, 0x02},
	/* External Clock Setting */
	{REG_EXCK_FREQ_MSB, 0x1A},
	{REG_EXCK_FREQ_LSB, 0x00},
	/* MIPI output setting */
	{REG_CSI_FORMAT_C, 0x0A},
	{REG_CSI_FORMAT_D, 0x0A},
	{REG_CSI_LANE, 0x01},
	/* Other Setting */
	{IMX477_REG_ORIENTATION, 0xff},
	{0x30D9, 0x01},
	{0x32D5, 0x00},
	{0x32D6, 0x00},
	{0x401E, 0x00},
	{0x40B8, 0x04},
	{0x40B9, 0xC4},
	{0x40BC, 0x00},
	{0x40BD, 0xB4},
	{0x40BE, 0x00},
	{0x40BF, 0xB4},
	{0x41A4, 0x06},
	{0x5A09, 0x01},
	{0x5A17, 0x01},
	{0x5A25, 0x01},
	{0x5A33, 0x01},
	{0x98D7, 0xB4},
	{0x98D8, 0x8C},
	{0x98D9, 0x0A},
	{0x99C4, 0x16},
	{SEQUENCE_END, 0x00}
};
//struct reginfo ONETIME_INIT_REG_SET2[] = {
//	{0x0103,  0x01}, /* Software reset        */
//
//	{0x3010,  0x01}, /* SLAVE_ADD_EN_2ND      */
//	{0x3011,  0x01}, /* SLAVE_ADD_ACKEN_2ND   */
//
//	{0x3F0B,  0x01}, /* Multi camera mode: on */
//
//	{0x3041,  0x01}, /* Mode: Master */
//	{0x3040,  0x01}, /* XVS pin: out */
//	{0x4B81,  0x01}, /* Mode: Master */
//
//	{0x3042,  0x00}, /* VSYNC Delay in lines [15:8]  */
//	{0x3043,  0x00}, /* VSYNC Delay in lines [7:0]   */
//	{0x3044,  0x00}, /* VSYNC Delay in clocks [15:8] */
//	{0x3045,  0x00}, /* VSYNC Delay in clocks [7:0]  */
//	{0x3045,  0x00}, /* VSYNC thin down setting      */
//
//	/* External Clock Setting */
//	{0x0136,  0x13}, /* External clock freq (dec) [15:8] */
//	{0x0137,  0x33}, /* External clock freq (dec) [7:0]  */
//
//	/* Global Setting */
//	{0x0808,  0x02}, /* MIPI Global Timing: Register Control */
//	{0xE07A,  0x01},
//	{0xE000,  0x00}, /* RUN/STOP of CSI2 during Frame Blanking: HS */
//	{0x4AE9,  0x18},
//	{0x4AEA,  0x08},
//	{0xF61C,  0x04},
//	{0xF61E,  0x04},
//	{0x4AE9,  0x21},
//	{0x4AEA,  0x80},
//	{0x38A8,  0x1F},
//	{0x38A9,  0xFF},
//	{0x38AA,  0x1F},
//	{0x38AB,  0xFF},
//	{0x420B,  0x01},
//	{0x55D4,  0x00},
//	{0x55D5,  0x00},
//	{0x55D6,  0x07},
//	{0x55D7,  0xFF},
//	{0x55E8,  0x07},
//	{0x55E9,  0xFF},
//	{0x55EA,  0x00},
//	{0x55EB,  0x00},
//	{0x574C,  0x07},
//	{0x574D,  0xFF},
//	{0x574E,  0x00},
//	{0x574F,  0x00},
//	{0x5754,  0x00},
//	{0x5755,  0x00},
//	{0x5756,  0x07},
//	{0x5757,  0xFF},
//	{0x5973,  0x04},
//	{0x5974,  0x01},
//	{0x5D13,  0xC3},
//	{0x5D14,  0x58},
//	{0x5D15,  0xA3},
//	{0x5D16,  0x1D},
//	{0x5D17,  0x65},
//	{0x5D18,  0x8C},
//	{0x5D1A,  0x06},
//	{0x5D1B,  0xA9},
//	{0x5D1C,  0x45},
//	{0x5D1D,  0x3A},
//	{0x5D1E,  0xAB},
//	{0x5D1F,  0x15},
//	{0x5D21,  0x0E},
//	{0x5D22,  0x52},
//	{0x5D23,  0xAA},
//	{0x5D24,  0x7D},
//	{0x5D25,  0x57},
//	{0x5D26,  0xA8},
//	{0x5D37,  0x5A},
//	{0x5D38,  0x5A},
//	{0x5D77,  0x7F},
//	{0x7B7C,  0x00},
//	{0x7B7D,  0x00},
//	{0x8D1F,  0x00},
//	{0x8D27,  0x00},
//	{0x9004,  0x03},
//	{0x9200,  0x50},
//	{0x9201,  0x6C},
//	{0x9202,  0x71},
//	{0x9203,  0x00},
//	{0x9204,  0x71},
//	{0x9205,  0x01},
//	{0x9371,  0x6A},
//	{0x9373,  0x6A},
//	{0x9375,  0x64},
//	{0x990C,  0x00},
//	{0x990D,  0x08},
//	{0x9956,  0x8C},
//	{0x9957,  0x64},
//	{0x9958,  0x50},
//	{0x9A48,  0x06},
//	{0x9A49,  0x06},
//	{0x9A4A,  0x06},
//	{0x9A4B,  0x06},
//	{0x9A4C,  0x06},
//	{0x9A4D,  0x06},
//	{0xA001,  0x0A},
//	{0xA003,  0x0A},
//	{0xA005,  0x0A},
//	{0xA006,  0x01},
//	{0xA007,  0xC0},
//	{0xA009,  0xC0},
//
//	/* Image Tuning */
//	{0x3D8A,  0x01},
//	{0x7B3B,  0x01},
//	{0x7B4C,  0x00},
//	{0x9905,  0x00},
//	{0x9907,  0x00},
//	{0x9909,  0x00},
//	{0x990B,  0x00},
//	{0x9944,  0x3C},
//	{0x9947,  0x3C},
//	{0x994A,  0x8C},
//	{0x994B,  0x50},
//	{0x994C,  0x1B},
//	{0x994D,  0x8C},
//	{0x994E,  0x50},
//	{0x994F,  0x1B},
//	{0x9950,  0x8C},
//	{0x9951,  0x1B},
//	{0x9952,  0x0A},
//	{0x9953,  0x8C},
//	{0x9954,  0x1B},
//	{0x9955,  0x0A},
//	{0x9A13,  0x04},
//	{0x9A14,  0x04},
//	{0x9A19,  0x00},
//	{0x9A1C,  0x04},
//	{0x9A1D,  0x04},
//	{0x9A26,  0x05},
//	{0x9A27,  0x05},
//	{0x9A2C,  0x01},
//	{0x9A2D,  0x03},
//	{0x9A2F,  0x05},
//	{0x9A30,  0x05},
//	{0x9A41,  0x00},
//	{0x9A46,  0x00},
//	{0x9A47,  0x00},
//	{0x9C17,  0x35},
//	{0x9C1D,  0x31},
//	{0x9C29,  0x50},
//	{0x9C3B,  0x2F},
//	{0x9C41,  0x6B},
//	{0x9C47,  0x2D},
//	{0x9C4D,  0x40},
//	{0x9C6B,  0x00},
//	{0x9C71,  0xC8},
//	{0x9C73,  0x32},
//	{0x9C75,  0x04},
//	{0x9C7D,  0x2D},
//	{0x9C83,  0x40},
//	{0x9C94,  0x3F},
//	{0x9C95,  0x3F},
//	{0x9C96,  0x3F},
//	{0x9C97,  0x00},
//	{0x9C98,  0x00},
//	{0x9C99,  0x00},
//	{0x9C9A,  0x3F},
//	{0x9C9B,  0x3F},
//	{0x9C9C,  0x3F},
//	{0x9CA0,  0x0F},
//	{0x9CA1,  0x0F},
//	{0x9CA2,  0x0F},
//	{0x9CA3,  0x00},
//	{0x9CA4,  0x00},
//	{0x9CA5,  0x00},
//	{0x9CA6,  0x1E},
//	{0x9CA7,  0x1E},
//	{0x9CA8,  0x1E},
//	{0x9CA9,  0x00},
//	{0x9CAA,  0x00},
//	{0x9CAB,  0x00},
//	{0x9CAC,  0x09},
//	{0x9CAD,  0x09},
//	{0x9CAE,  0x09},
//	{0x9CBD,  0x50},
//	{0x9CBF,  0x50},
//	{0x9CC1,  0x50},
//	{0x9CC3,  0x40},
//	{0x9CC5,  0x40},
//	{0x9CC7,  0x40},
//	{0x9CC9,  0x0A},
//	{0x9CCB,  0x0A},
//	{0x9CCD,  0x0A},
//	{0x9D17,  0x35},
//	{0x9D1D,  0x31},
//	{0x9D29,  0x50},
//	{0x9D3B,  0x2F},
//	{0x9D41,  0x6B},
//	{0x9D47,  0x42},
//	{0x9D4D,  0x5A},
//	{0x9D6B,  0x00},
//	{0x9D71,  0xC8},
//	{0x9D73,  0x32},
//	{0x9D75,  0x04},
//	{0x9D7D,  0x42},
//	{0x9D83,  0x5A},
//	{0x9D94,  0x3F},
//	{0x9D95,  0x3F},
//	{0x9D96,  0x3F},
//	{0x9D97,  0x00},
//	{0x9D98,  0x00},
//	{0x9D99,  0x00},
//	{0x9D9A,  0x3F},
//	{0x9D9B,  0x3F},
//	{0x9D9C,  0x3F},
//	{0x9D9D,  0x1F},
//	{0x9D9E,  0x1F},
//	{0x9D9F,  0x1F},
//	{0x9DA0,  0x0F},
//	{0x9DA1,  0x0F},
//	{0x9DA2,  0x0F},
//	{0x9DA3,  0x00},
//	{0x9DA4,  0x00},
//	{0x9DA5,  0x00},
//	{0x9DA6,  0x1E},
//	{0x9DA7,  0x1E},
//	{0x9DA8,  0x1E},
//	{0x9DA9,  0x00},
//	{0x9DAA,  0x00},
//	{0x9DAB,  0x00},
//	{0x9DAC,  0x09},
//	{0x9DAD,  0x09},
//	{0x9DAE,  0x09},
//	{0x9DC9,  0x0A},
//	{0x9DCB,  0x0A},
//	{0x9DCD,  0x0A},
//	{0x9E17,  0x35},
//	{0x9E1D,  0x31},
//	{0x9E29,  0x50},
//	{0x9E3B,  0x2F},
//	{0x9E41,  0x6B},
//	{0x9E47,  0x2D},
//	{0x9E4D,  0x40},
//	{0x9E6B,  0x00},
//	{0x9E71,  0xC8},
//	{0x9E73,  0x32},
//	{0x9E75,  0x04},
//	{0x9E94,  0x0F},
//	{0x9E95,  0x0F},
//	{0x9E96,  0x0F},
//	{0x9E97,  0x00},
//	{0x9E98,  0x00},
//	{0x9E99,  0x00},
//	{0x9EA0,  0x0F},
//	{0x9EA1,  0x0F},
//	{0x9EA2,  0x0F},
//	{0x9EA3,  0x00},
//	{0x9EA4,  0x00},
//	{0x9EA5,  0x00},
//	{0x9EA6,  0x3F},
//	{0x9EA7,  0x3F},
//	{0x9EA8,  0x3F},
//	{0x9EA9,  0x00},
//	{0x9EAA,  0x00},
//	{0x9EAB,  0x00},
//	{0x9EAC,  0x09},
//	{0x9EAD,  0x09},
//	{0x9EAE,  0x09},
//	{0x9EC9,  0x0A},
//	{0x9ECB,  0x0A},
//	{0x9ECD,  0x0A},
//	{0x9F17,  0x35},
//	{0x9F1D,  0x31},
//	{0x9F29,  0x50},
//	{0x9F3B,  0x2F},
//	{0x9F41,  0x6B},
//	{0x9F47,  0x42},
//	{0x9F4D,  0x5A},
//	{0x9F6B,  0x00},
//	{0x9F71,  0xC8},
//	{0x9F73,  0x32},
//	{0x9F75,  0x04},
//	{0x9F94,  0x0F},
//	{0x9F95,  0x0F},
//	{0x9F96,  0x0F},
//	{0x9F97,  0x00},
//	{0x9F98,  0x00},
//	{0x9F99,  0x00},
//	{0x9F9A,  0x2F},
//	{0x9F9B,  0x2F},
//	{0x9F9C,  0x2F},
//	{0x9F9D,  0x00},
//	{0x9F9E,  0x00},
//	{0x9F9F,  0x00},
//	{0x9FA0,  0x0F},
//	{0x9FA1,  0x0F},
//	{0x9FA2,  0x0F},
//	{0x9FA3,  0x00},
//	{0x9FA4,  0x00},
//	{0x9FA5,  0x00},
//	{0x9FA6,  0x1E},
//	{0x9FA7,  0x1E},
//	{0x9FA8,  0x1E},
//	{0x9FA9,  0x00},
//	{0x9FAA,  0x00},
//	{0x9FAB,  0x00},
//	{0x9FAC,  0x09},
//	{0x9FAD,  0x09},
//	{0x9FAE,  0x09},
//	{0x9FC9,  0x0A},
//	{0x9FCB,  0x0A},
//	{0x9FCD,  0x0A},
//	{0xA14B,  0xFF},
//	{0xA151,  0x0C},
//	{0xA153,  0x50},
//	{0xA155,  0x02},
//	{0xA157,  0x00},
//	{0xA1AD,  0xFF},
//	{0xA1B3,  0x0C},
//	{0xA1B5,  0x50},
//	{0xA1B9,  0x00},
//	{0xA24B,  0xFF},
//	{0xA257,  0x00},
//	{0xA2AD,  0xFF},
//	{0xA2B9,  0x00},
//	{0xB21F,  0x04},
//	{0xB35C,  0x00},
//	{0xB35E,  0x08},
//	{REG_MODE_SEL, 0x01},
//	{SEQUENCE_END, 0x00}
//};


//struct reginfo ONETIME_INIT_REG_SET3[] =
//{
//	{REG_EXCK_FREQ_MSB, 0x18},
//	{REG_EXCK_FREQ_LSB, 0x00},
//	{REG_FRAME_BLANKSTOP_CTRL, 0x00},
//	{0xe07a, 0x01},
//	{REG_DPHY_CTRL, 0x02},
//	{0x4ae9, 0x18},
//	{0x4aea, 0x08},
//	{0xf61c, 0x04},
//	{0xf61e, 0x04},
//	{0x4ae9, 0x21},
//	{0x4aea, 0x80},
//	{0x38a8, 0x1f},
//	{0x38a9, 0xff},
//	{0x38aa, 0x1f},
//	{0x38ab, 0xff},
//	{0x55d4, 0x00},
//	{0x55d5, 0x00},
//	{0x55d6, 0x07},
//	{0x55d7, 0xff},
//	{0x55e8, 0x07},
//	{0x55e9, 0xff},
//	{0x55ea, 0x00},
//	{0x55eb, 0x00},
//	{0x574c, 0x07},
//	{0x574d, 0xff},
//	{0x574e, 0x00},
//	{0x574f, 0x00},
//	{0x5754, 0x00},
//	{0x5755, 0x00},
//	{0x5756, 0x07},
//	{0x5757, 0xff},
//	{0x5973, 0x04},
//	{0x5974, 0x01},
//	{0x5d13, 0xc3},
//	{0x5d14, 0x58},
//	{0x5d15, 0xa3},
//	{0x5d16, 0x1d},
//	{0x5d17, 0x65},
//	{0x5d18, 0x8c},
//	{0x5d1a, 0x06},
//	{0x5d1b, 0xa9},
//	{0x5d1c, 0x45},
//	{0x5d1d, 0x3a},
//	{0x5d1e, 0xab},
//	{0x5d1f, 0x15},
//	{0x5d21, 0x0e},
//	{0x5d22, 0x52},
//	{0x5d23, 0xaa},
//	{0x5d24, 0x7d},
//	{0x5d25, 0x57},
//	{0x5d26, 0xa8},
//	{0x5d37, 0x5a},
//	{0x5d38, 0x5a},
//	{0x5d77, 0x7f},
//	{0x7b75, 0x0e},
//	{0x7b76, 0x0b},
//	{0x7b77, 0x08},
//	{0x7b78, 0x0a},
//	{0x7b79, 0x47},
//	{0x7b7c, 0x00},
//	{0x7b7d, 0x00},
//	{0x8d1f, 0x00},
//	{0x8d27, 0x00},
//	{0x9004, 0x03},
//	{0x9200, 0x50},
//	{0x9201, 0x6c},
//	{0x9202, 0x71},
//	{0x9203, 0x00},
//	{0x9204, 0x71},
//	{0x9205, 0x01},
//	{0x9371, 0x6a},
//	{0x9373, 0x6a},
//	{0x9375, 0x64},
//	{0x991a, 0x00},
//	{0x996b, 0x8c},
//	{0x996c, 0x64},
//	{0x996d, 0x50},
//	{0x9a4c, 0x0d},
//	{0x9a4d, 0x0d},
//	{0xa001, 0x0a},
//	{0xa003, 0x0a},
//	{0xa005, 0x0a},
//	{0xa006, 0x01},
//	{0xa007, 0xc0},
//	{0xa009, 0xc0},
//	{0x3d8a, 0x01},
//	{0x4421, 0x04},
//	{0x7b3b, 0x01},
//	{0x7b4c, 0x00},
//	{0x9905, 0x00},
//	{0x9907, 0x00},
//	{0x9909, 0x00},
//	{0x990b, 0x00},
//	{0x9944, 0x3c},
//	{0x9947, 0x3c},
//	{0x994a, 0x8c},
//	{0x994b, 0x50},
//	{0x994c, 0x1b},
//	{0x994d, 0x8c},
//	{0x994e, 0x50},
//	{0x994f, 0x1b},
//	{0x9950, 0x8c},
//	{0x9951, 0x1b},
//	{0x9952, 0x0a},
//	{0x9953, 0x8c},
//	{0x9954, 0x1b},
//	{0x9955, 0x0a},
//	{0x9a13, 0x04},
//	{0x9a14, 0x04},
//	{0x9a19, 0x00},
//	{0x9a1c, 0x04},
//	{0x9a1d, 0x04},
//	{0x9a26, 0x05},
//	{0x9a27, 0x05},
//	{0x9a2c, 0x01},
//	{0x9a2d, 0x03},
//	{0x9a2f, 0x05},
//	{0x9a30, 0x05},
//	{0x9a41, 0x00},
//	{0x9a46, 0x00},
//	{0x9a47, 0x00},
//	{0x9c17, 0x35},
//	{0x9c1d, 0x31},
//	{0x9c29, 0x50},
//	{0x9c3b, 0x2f},
//	{0x9c41, 0x6b},
//	{0x9c47, 0x2d},
//	{0x9c4d, 0x40},
//	{0x9c6b, 0x00},
//	{0x9c71, 0xc8},
//	{0x9c73, 0x32},
//	{0x9c75, 0x04},
//	{0x9c7d, 0x2d},
//	{0x9c83, 0x40},
//	{0x9c94, 0x3f},
//	{0x9c95, 0x3f},
//	{0x9c96, 0x3f},
//	{0x9c97, 0x00},
//	{0x9c98, 0x00},
//	{0x9c99, 0x00},
//	{0x9c9a, 0x3f},
//	{0x9c9b, 0x3f},
//	{0x9c9c, 0x3f},
//	{0x9ca0, 0x0f},
//	{0x9ca1, 0x0f},
//	{0x9ca2, 0x0f},
//	{0x9ca3, 0x00},
//	{0x9ca4, 0x00},
//	{0x9ca5, 0x00},
//	{0x9ca6, 0x1e},
//	{0x9ca7, 0x1e},
//	{0x9ca8, 0x1e},
//	{0x9ca9, 0x00},
//	{0x9caa, 0x00},
//	{0x9cab, 0x00},
//	{0x9cac, 0x09},
//	{0x9cad, 0x09},
//	{0x9cae, 0x09},
//	{0x9cbd, 0x50},
//	{0x9cbf, 0x50},
//	{0x9cc1, 0x50},
//	{0x9cc3, 0x40},
//	{0x9cc5, 0x40},
//	{0x9cc7, 0x40},
//	{0x9cc9, 0x0a},
//	{0x9ccb, 0x0a},
//	{0x9ccd, 0x0a},
//	{0x9d17, 0x35},
//	{0x9d1d, 0x31},
//	{0x9d29, 0x50},
//	{0x9d3b, 0x2f},
//	{0x9d41, 0x6b},
//	{0x9d47, 0x42},
//	{0x9d4d, 0x5a},
//	{0x9d6b, 0x00},
//	{0x9d71, 0xc8},
//	{0x9d73, 0x32},
//	{0x9d75, 0x04},
//	{0x9d7d, 0x42},
//	{0x9d83, 0x5a},
//	{0x9d94, 0x3f},
//	{0x9d95, 0x3f},
//	{0x9d96, 0x3f},
//	{0x9d97, 0x00},
//	{0x9d98, 0x00},
//	{0x9d99, 0x00},
//	{0x9d9a, 0x3f},
//	{0x9d9b, 0x3f},
//	{0x9d9c, 0x3f},
//	{0x9d9d, 0x1f},
//	{0x9d9e, 0x1f},
//	{0x9d9f, 0x1f},
//	{0x9da0, 0x0f},
//	{0x9da1, 0x0f},
//	{0x9da2, 0x0f},
//	{0x9da3, 0x00},
//	{0x9da4, 0x00},
//	{0x9da5, 0x00},
//	{0x9da6, 0x1e},
//	{0x9da7, 0x1e},
//	{0x9da8, 0x1e},
//	{0x9da9, 0x00},
//	{0x9daa, 0x00},
//	{0x9dab, 0x00},
//	{0x9dac, 0x09},
//	{0x9dad, 0x09},
//	{0x9dae, 0x09},
//	{0x9dc9, 0x0a},
//	{0x9dcb, 0x0a},
//	{0x9dcd, 0x0a},
//	{0x9e17, 0x35},
//	{0x9e1d, 0x31},
//	{0x9e29, 0x50},
//	{0x9e3b, 0x2f},
//	{0x9e41, 0x6b},
//	{0x9e47, 0x2d},
//	{0x9e4d, 0x40},
//	{0x9e6b, 0x00},
//	{0x9e71, 0xc8},
//	{0x9e73, 0x32},
//	{0x9e75, 0x04},
//	{0x9e94, 0x0f},
//	{0x9e95, 0x0f},
//	{0x9e96, 0x0f},
//	{0x9e97, 0x00},
//	{0x9e98, 0x00},
//	{0x9e99, 0x00},
//	{0x9ea0, 0x0f},
//	{0x9ea1, 0x0f},
//	{0x9ea2, 0x0f},
//	{0x9ea3, 0x00},
//	{0x9ea4, 0x00},
//	{0x9ea5, 0x00},
//	{0x9ea6, 0x3f},
//	{0x9ea7, 0x3f},
//	{0x9ea8, 0x3f},
//	{0x9ea9, 0x00},
//	{0x9eaa, 0x00},
//	{0x9eab, 0x00},
//	{0x9eac, 0x09},
//	{0x9ead, 0x09},
//	{0x9eae, 0x09},
//	{0x9ec9, 0x0a},
//	{0x9ecb, 0x0a},
//	{0x9ecd, 0x0a},
//	{0x9f17, 0x35},
//	{0x9f1d, 0x31},
//	{0x9f29, 0x50},
//	{0x9f3b, 0x2f},
//	{0x9f41, 0x6b},
//	{0x9f47, 0x42},
//	{0x9f4d, 0x5a},
//	{0x9f6b, 0x00},
//	{0x9f71, 0xc8},
//	{0x9f73, 0x32},
//	{0x9f75, 0x04},
//	{0x9f94, 0x0f},
//	{0x9f95, 0x0f},
//	{0x9f96, 0x0f},
//	{0x9f97, 0x00},
//	{0x9f98, 0x00},
//	{0x9f99, 0x00},
//	{0x9f9a, 0x2f},
//	{0x9f9b, 0x2f},
//	{0x9f9c, 0x2f},
//	{0x9f9d, 0x00},
//	{0x9f9e, 0x00},
//	{0x9f9f, 0x00},
//	{0x9fa0, 0x0f},
//	{0x9fa1, 0x0f},
//	{0x9fa2, 0x0f},
//	{0x9fa3, 0x00},
//	{0x9fa4, 0x00},
//	{0x9fa5, 0x00},
//	{0x9fa6, 0x1e},
//	{0x9fa7, 0x1e},
//	{0x9fa8, 0x1e},
//	{0x9fa9, 0x00},
//	{0x9faa, 0x00},
//	{0x9fab, 0x00},
//	{0x9fac, 0x09},
//	{0x9fad, 0x09},
//	{0x9fae, 0x09},
//	{0x9fc9, 0x0a},
//	{0x9fcb, 0x0a},
//	{0x9fcd, 0x0a},
//	{0xa14b, 0xff},
//	{0xa151, 0x0c},
//	{0xa153, 0x50},
//	{0xa155, 0x02},
//	{0xa157, 0x00},
//	{0xa1ad, 0xff},
//	{0xa1b3, 0x0c},
//	{0xa1b5, 0x50},
//	{0xa1b9, 0x00},
//	{0xa24b, 0xff},
//	{0xa257, 0x00},
//	{0xa2ad, 0xff},
//	{0xa2b9, 0x00},
//	{0xb21f, 0x04},
//	{0xb35c, 0x00},
//	{0xb35e, 0x08},
//	{REG_CSI_FORMAT_C, 0x0a},
//	{REG_CSI_FORMAT_D, 0x0a},
//	{REG_CSI_LANE, 0x01},
//	{0x0350, 0x00},
//	{0xbcf1, 0x02},
//	{0x3ff9, 0x01},
//	{SEQUENCE_END, 0x00}
//};


/* 1080p cropped mode */
struct reginfo RESOLUTION_2028X1080_REGS[] = {
	{REG_LINE_LEN_MSB, 0x31},
	{REG_LINE_LEN_LSB, 0xc4},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x01},
	{REG_Y_ADD_STA_LSB, 0xb8},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},
	{REG_Y_ADD_END_MSB, 0x0a},
	{REG_Y_ADD_END_LSB, 0x27},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x12},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x03},
	{0x3c02, 0xa2},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x07},
	{0x5749, 0xff},
	{0x574a, 0x00},
	{0x574b, 0x00},
	{0x7b53, 0x01},
	{0x9369, 0x73},
	{0x936b, 0x64},
	{0x936d, 0x5f},
	{0x9304, 0x00},
	{0x9305, 0x00},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x60},
	{0xa2b7, 0x00},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x20},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0xd8},
	{REG_DIG_CROP_HEIGHT_MSB, 0x04},
	{REG_DIG_CROP_HEIGHT_LSB, 0x38},
	{REG_X_OUT_SIZE_MSB, 0x07},
	{REG_X_OUT_SIZE_LSB, 0xEC},
	{REG_Y_OUT_SIZE_MSB, 0x04},
	{REG_Y_OUT_SIZE_LSB, 0x38},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0x9B},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x85},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x7f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x6C},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};

/* 2x2 binned.  */
struct reginfo RESOLUTION_2028X1520_REGS[] = {
	{REG_LINE_LEN_MSB, 0x31},
	{REG_LINE_LEN_LSB, 0xc4},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x00},
	{REG_Y_ADD_STA_LSB, 0x00},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},
	{REG_Y_ADD_END_MSB, 0x0b},
	{REG_Y_ADD_END_LSB, 0xdf},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x12},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x03},
	{0x3c02, 0xa2},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x07},
	{0x5749, 0xff},
	{0x574a, 0x00},
	{0x574b, 0x00},
	{0x7b53, 0x01},
	{0x9369, 0x73},
	{0x936b, 0x64},
	{0x936d, 0x5f},
	{0x9304, 0x00},
	{0x9305, 0x00},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x60},
	{0xa2b7, 0x00},
	{REG_SCALE_MODE, 0x01},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x20},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0xd8},
	{REG_DIG_CROP_HEIGHT_MSB, 0x0b},
	{REG_DIG_CROP_HEIGHT_LSB, 0xE0},
	{REG_X_OUT_SIZE_MSB, 0x07},
	{REG_X_OUT_SIZE_LSB, 0xec},
	{REG_Y_OUT_SIZE_MSB, 0x05},
	{REG_Y_OUT_SIZE_LSB, 0xF0},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0x9B},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x85},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x7f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x6c},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
//4x4 binning 10bit
struct reginfo RESOLUTION_1332X990_REGS[] = {
	{0x420b, 0x01},
	{0x990c, 0x00},
	{0x990d, 0x08},
	{0x9956, 0x8c},
	{0x9957, 0x64},
	{0x9958, 0x50},
	{0x9a48, 0x06},
	{0x9a49, 0x06},
	{0x9a4a, 0x06},
	{0x9a4b, 0x06},
	{0x9a4c, 0x06},
	{0x9a4d, 0x06},
	{REG_LINE_LEN_MSB, 0x1a},
	{REG_LINE_LEN_LSB, 0x08},
	{REG_FRAME_LEN_MSB, 0x04},
	{REG_FRAME_LEN_LSB, 0x1a},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x02},
	{REG_Y_ADD_STA_LSB, 0x10},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},
	{REG_Y_ADD_END_MSB, 0x09},
	{REG_Y_ADD_END_LSB, 0xcf},
	{REG_DOL_HDR_EN, 0x00},
	{REG_DOL_HDR_NUM, 0x00},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0a},
	{REG_DOL_CONST, 0x00},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x22},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x01},
	{0x3c02, 0x9c},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x00},
	{0x5749, 0x00},
	{0x574a, 0x00},
	{0x574b, 0xa4},
	{0x7b75, 0x0e},
	{0x7b76, 0x09},
	{0x7b77, 0x08},
	{0x7b78, 0x06},
	{0x7b79, 0x34},
	{0x7b53, 0x00},
	{0x9369, 0x73},
	{0x936b, 0x64},
	{0x936d, 0x5f},
	{0x9304, 0x03},
	{0x9305, 0x80},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x27},
	{0xa2b7, 0x03},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x01},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x5c},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x05},
	{REG_DIG_CROP_WIDTH_LSB, 0x34},
	{REG_DIG_CROP_HEIGHT_MSB, 0x03},
	{REG_DIG_CROP_HEIGHT_LSB, 0xde},
	{REG_X_OUT_SIZE_MSB, 0x05},
	{REG_X_OUT_SIZE_LSB, 0x34},
	{REG_Y_OUT_SIZE_MSB, 0x03},
	{REG_Y_OUT_SIZE_LSB, 0xde},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0x9B},
	{REG_IOPPXCK_DIV, 0x0a},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x85},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x5f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x00},
	{REG_LINE_LEN_INCLK_LSB, 0xbf},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo RESOLUTION1_1920X1080_REGS[] =
{
     /* Line Length PCK Setting */
	{REG_LINE_LEN_MSB, 0x31},
	{REG_LINE_LEN_LSB, 0xc4},
    /* ROI Setting */

    /* X ROI SIZE 0 TO 4055 = 4056*/
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},

    /* Y ROI SIZE 440 TO 2599 = 2159*/
	{REG_Y_ADD_STA_MSB, 0x01},
	{REG_Y_ADD_STA_LSB, 0xb8},
	{REG_Y_ADD_END_MSB, 0x0a},
	{REG_Y_ADD_END_LSB, 0x27},

    /* X CROP SIZE 4056*/
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0xd7},

    /* Y CROP SIZE 1080*/
	{REG_DIG_CROP_HEIGHT_MSB, 0x05},
	{REG_DIG_CROP_HEIGHT_LSB, 0xb0},

    /* X OUT SIZE 2048*/
	{REG_X_OUT_SIZE_MSB, 0x08},
	{REG_X_OUT_SIZE_LSB, 0x00},

    /* Y OUT SIZE 1080*/
	{REG_Y_OUT_SIZE_MSB, 0x04},
	{REG_Y_OUT_SIZE_LSB, 0xb0},

	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},


	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x12},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x03},
	{0x3c02, 0xa2},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x07},
	{0x5749, 0xff},
	{0x574a, 0x00},
	{0x574b, 0x00},
	{0x7b53, 0x01},
	{0x9369, 0x73},
	{0x936b, 0x64},
	{0x936d, 0x5f},
	{0x9304, 0x00},
	{0x9305, 0x00},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x60},
	{0xa2b7, 0x00},
	{REG_SCALE_MODE, 0x01},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x20},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x5e},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x96},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x7f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x6c},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x02},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo RESOLUTION3_1920X1080_REGS[] =
{
     /* Line Length PCK Setting */
	{REG_LINE_LEN_MSB, 0x31},
	{REG_LINE_LEN_LSB, 0xc4},
    /* ROI Setting */
    /* X ROI SIZE 0 TO 4055 = 4056*/
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},
    /* Y ROI SIZE 440 TO 2599 = 2159*/
	{REG_Y_ADD_STA_MSB, 0x01},
	{REG_Y_ADD_STA_LSB, 0xb8},
	{REG_Y_ADD_END_MSB, 0x0a},
	{REG_Y_ADD_END_LSB, 0x27},
    /* X CROP SIZE 4056*/
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0xd7},
    /* Y CROP SIZE 1080*/
	{REG_DIG_CROP_HEIGHT_MSB, 0x04},
	{REG_DIG_CROP_HEIGHT_LSB, 0xb0},
    /* X OUT SIZE 2048*/
	{REG_X_OUT_SIZE_MSB, 0x08},
	{REG_X_OUT_SIZE_LSB, 0x00},
    /* Y OUT SIZE 1080*/
	{REG_Y_OUT_SIZE_MSB, 0x04},
	{REG_Y_OUT_SIZE_LSB, 0xb0},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x12},
	{REG_BINNING_WEIGHTING, 0x02},
	{REG_ADC_BIT_SETTING, 0x0A},
	{REG_SCALE_MODE, 0x01},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x20},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x5e},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x96},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x6c},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L, 0x00},
	{REG_DIG_GAIN_GB_U, 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x02},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};

struct reginfo RESOLUTION2_1920X1080_REGS[] =
{
	/* MIPI output setting */
	{REG_CSI_FORMAT_C, 0x0A},
	{REG_CSI_FORMAT_D, 0x0A},
	{REG_CSI_LANE, 0x01},
	/* Line Length PCK Setting */
	{REG_LINE_LEN_MSB, 0x23},
	{REG_LINE_LEN_LSB, 0x40},
	/* Frame Length Lines Setting */
	{REG_FRAME_LEN_MSB, 0x06},
	{REG_FRAME_LEN_LSB, 0x0F},

	/* ROI Setting */

    /* X ROI SIZE 0 TO 4055 = 4056*/
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},

    /* Y ROI SIZE 376 TO 2663 = 2287*/
	{REG_Y_ADD_STA_MSB, 0x01},
	{REG_Y_ADD_STA_LSB, 0x78},
	{REG_Y_ADD_END_MSB, 0x0A},
	{REG_Y_ADD_END_LSB, 0x67},



    /* X CROP SIZE 4056*/
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0xd7},

    /* Y CROP SIZE 1080*/
	{REG_DIG_CROP_HEIGHT_MSB, 0x04},
	{REG_DIG_CROP_HEIGHT_LSB, 0x38},

    /* X OUT SIZE 2048*/
	{REG_X_OUT_SIZE_MSB, 0x08},
	{REG_X_OUT_SIZE_LSB, 0x00},

    /* Y OUT SIZE 1080*/
	{REG_Y_OUT_SIZE_MSB, 0x04},
	{REG_Y_OUT_SIZE_LSB, 0x38},

	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},

	{REG_DOL_HDR_EN, 0x00},
	{REG_DOL_HDR_NUM, 0x00},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0A},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	/* Mode Setting */
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x22},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3C00, 0x00},
	{0x3C01, 0x01},
	{0x3C02, 0x9C},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x00},
	{0x5749, 0x00},
	{0x574A, 0x00},
	{0x574B, 0xA4},
	{0x7B75, 0x0E},
	{0x7B76, 0x09},
	{0x7B77, 0x08},
	{0x7B78, 0x06},
	{0x7B79, 0x34},
	{0x7B53, 0x00},
	{0x9369, 0x73},
	{0x936B, 0x64},
	{0x936D, 0x5F},
	{0x9304, 0x03},
	{0x9305, 0x80},
	{0x9E9A, 0x2F},
	{0x9E9B, 0x2F},
	{0x9E9C, 0x2F},
	{0x9E9D, 0x00},
	{0x9E9E, 0x00},
	{0x9E9F, 0x00},
	{0xA2A9, 0x27},
	{0xA2B7, 0x03},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},

	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0xAF},
	{REG_IOPPXCK_DIV, 0x0A},
	{REG_IOPSYCK_DIV, 0x01},
	{REG_IOP_PREPLLCK_DIV, 0x03},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x96},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x09},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x60},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x87},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4F},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x87},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5F},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x5F},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4F},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x3F},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3F},
	{0xE04C, 0x00},
	{0xE04D, 0x87},
	{0xE04E, 0x00},
	{0xE04F, 0x1F},
	{0x3E20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x02},
	{0X3FF9, 0x01},
	{IMX477_REG_ORIENTATION, 0xff},
	/* Image Tuning */
	{0x3D8A, 0x01},
	{0x7B3B, 0x01},
	{0x7B4C, 0x00},
	{0x9905, 0x00},
	{0x9907, 0x00},
	{0x9909, 0x00},
	{0x990B, 0x00},
	{0x9944, 0x3C},
	{0x9947, 0x3C},
	{0x994A, 0x8C},
	{0x994B, 0x50},
	{0x994C, 0x1B},
	{0x994D, 0x8C},
	{0x994E, 0x50},
	{0x994F, 0x1B},
	{0x9950, 0x8C},
	{0x9951, 0x1B},
	{0x9952, 0x0A},
	{0x9953, 0x8C},
	{0x9954, 0x1B},
	{0x9955, 0x0A},
	{0x9A13, 0x04},
	{0x9A14, 0x04},
	{0x9A19, 0x00},
	{0x9A1C, 0x04},
	{0x9A1D, 0x04},
	{0x9A26, 0x05},
	{0x9A27, 0x05},
	{0x9A2C, 0x01},
	{0x9A2D, 0x03},
	{0x9A2F, 0x05},
	{0x9A30, 0x05},
	{0x9A41, 0x00},
	{0x9A46, 0x00},
	{0x9A47, 0x00},
	{0x9C17, 0x35},
	{0x9C1D, 0x31},
	{0x9C29, 0x50},
	{0x9C3B, 0x2F},
	{0x9C41, 0x6B},
	{0x9C47, 0x2D},
	{0x9C4D, 0x40},
	{0x9C6B, 0x00},
	{0x9C71, 0xC8},
	{0x9C73, 0x32},
	{0x9C75, 0x04},
	{0x9C7D, 0x2D},
	{0x9C83, 0x40},
	{0x9C94, 0x3F},
	{0x9C95, 0x3F},
	{0x9C96, 0x3F},
	{0x9C97, 0x00},
	{0x9C98, 0x00},
	{0x9C99, 0x00},
	{0x9C9A, 0x3F},
	{0x9C9B, 0x3F},
	{0x9C9C, 0x3F},
	{0x9CA0, 0x0F},
	{0x9CA1, 0x0F},
	{0x9CA2, 0x0F},
	{0x9CA3, 0x00},
	{0x9CA4, 0x00},
	{0x9CA5, 0x00},
	{0x9CA6, 0x1E},
	{0x9CA7, 0x1E},
	{0x9CA8, 0x1E},
	{0x9CA9, 0x00},
	{0x9CAA, 0x00},
	{0x9CAB, 0x00},
	{0x9CAC, 0x09},
	{0x9CAD, 0x09},
	{0x9CAE, 0x09},
	{0x9CBD, 0x50},
	{0x9CBF, 0x50},
	{0x9CC1, 0x50},
	{0x9CC3, 0x40},
	{0x9CC5, 0x40},
	{0x9CC7, 0x40},
	{0x9CC9, 0x0A},
	{0x9CCB, 0x0A},
	{0x9CCD, 0x0A},
	{0x9D17, 0x35},
	{0x9D1D, 0x31},
	{0x9D29, 0x50},
	{0x9D3B, 0x2F},
	{0x9D41, 0x6B},
	{0x9D47, 0x42},
	{0x9D4D, 0x5A},
	{0x9D6B, 0x00},
	{0x9D71, 0xC8},
	{0x9D73, 0x32},
	{0x9D75, 0x04},
	{0x9D7D, 0x42},
	{0x9D83, 0x5A},
	{0x9D94, 0x3F},
	{0x9D95, 0x3F},
	{0x9D96, 0x3F},
	{0x9D97, 0x00},
	{0x9D98, 0x00},
	{0x9D99, 0x00},
	{0x9D9A, 0x3F},
	{0x9D9B, 0x3F},
	{0x9D9C, 0x3F},
	{0x9D9D, 0x1F},
	{0x9D9E, 0x1F},
	{0x9D9F, 0x1F},
	{0x9DA0, 0x0F},
	{0x9DA1, 0x0F},
	{0x9DA2, 0x0F},
	{0x9DA3, 0x00},
	{0x9DA4, 0x00},
	{0x9DA5, 0x00},
	{0x9DA6, 0x1E},
	{0x9DA7, 0x1E},
	{0x9DA8, 0x1E},
	{0x9DA9, 0x00},
	{0x9DAA, 0x00},
	{0x9DAB, 0x00},
	{0x9DAC, 0x09},
	{0x9DAD, 0x09},
	{0x9DAE, 0x09},
	{0x9DC9, 0x0A},
	{0x9DCB, 0x0A},
	{0x9DCD, 0x0A},
	{0x9E17, 0x35},
	{0x9E1D, 0x31},
	{0x9E29, 0x50},
	{0x9E3B, 0x2F},
	{0x9E41, 0x6B},
	{0x9E47, 0x2D},
	{0x9E4D, 0x40},
	{0x9E6B, 0x00},
	{0x9E71, 0xC8},
	{0x9E73, 0x32},
	{0x9E75, 0x04},
	{0x9E94, 0x0F},
	{0x9E95, 0x0F},
	{0x9E96, 0x0F},
	{0x9E97, 0x00},
	{0x9E98, 0x00},
	{0x9E99, 0x00},
	{0x9EA0, 0x0F},
	{0x9EA1, 0x0F},
	{0x9EA2, 0x0F},
	{0x9EA3, 0x00},
	{0x9EA4, 0x00},
	{0x9EA5, 0x00},
	{0x9EA6, 0x3F},
	{0x9EA7, 0x3F},
	{0x9EA8, 0x3F},
	{0x9EA9, 0x00},
	{0x9EAA, 0x00},
	{0x9EAB, 0x00},
	{0x9EAC, 0x09},
	{0x9EAD, 0x09},
	{0x9EAE, 0x09},
	{0x9EC9, 0x0A},
	{0x9ECB, 0x0A},
	{0x9ECD, 0x0A},
	{0x9F17, 0x35},
	{0x9F1D, 0x31},
	{0x9F29, 0x50},
	{0x9F3B, 0x2F},
	{0x9F41, 0x6B},
	{0x9F47, 0x42},
	{0x9F4D, 0x5A},
	{0x9F6B, 0x00},
	{0x9F71, 0xC8},
	{0x9F73, 0x32},
	{0x9F75, 0x04},
	{0x9F94, 0x0F},
	{0x9F95, 0x0F},
	{0x9F96, 0x0F},
	{0x9F97, 0x00},
	{0x9F98, 0x00},
	{0x9F99, 0x00},
	{0x9F9A, 0x2F},
	{0x9F9B, 0x2F},
	{0x9F9C, 0x2F},
	{0x9F9D, 0x00},
	{0x9F9E, 0x00},
	{0x9F9F, 0x00},
	{0x9FA0, 0x0F},
	{0x9FA1, 0x0F},
	{0x9FA2, 0x0F},
	{0x9FA3, 0x00},
	{0x9FA4, 0x00},
	{0x9FA5, 0x00},
	{0x9FA6, 0x1E},
	{0x9FA7, 0x1E},
	{0x9FA8, 0x1E},
	{0x9FA9, 0x00},
	{0x9FAA, 0x00},
	{0x9FAB, 0x00},
	{0x9FAC, 0x09},
	{0x9FAD, 0x09},
	{0x9FAE, 0x09},
	{0x9FC9, 0x0A},
	{0x9FCB, 0x0A},
	{0x9FCD, 0x0A},
	{0xA14B, 0xFF},
	{0xA151, 0x0C},
	{0xA153, 0x50},
	{0xA155, 0x02},
	{0xA157, 0x00},
	{0xA1AD, 0xFF},
	{0xA1B3, 0x0C},
	{0xA1B5, 0x50},
	{0xA1B9, 0x00},
	{0xA24B, 0xFF},
	{0xA257, 0x00},
	{0xA2AD, 0xFF},
	{0xA2B9, 0x00},
	{0xB21F, 0x04},
	{0xB35C, 0x00},
	{0xB35E, 0x08},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
/*4056x2288 30fps 10b*/
struct reginfo sensor_4k_regs[] =
{
	{REG_MODE_SEL, 0x00},
	{REG_DLY, 0x20},
	{REG_CSI_FORMAT_C, 0x0A},
	{REG_CSI_FORMAT_D, 0x0A},
	{REG_CSI_LANE, 0x01},
	{REG_LINE_LEN_MSB, 0x1E},
	{REG_LINE_LEN_LSB, 0x14},
	{REG_FRAME_LEN_MSB, 0x0E},
	{REG_FRAME_LEN_LSB, 0x38},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x01},
	{REG_Y_ADD_STA_LSB, 0x78},
	{REG_X_ADD_END_MSB, 0x0F},
	{REG_X_ADD_END_LSB, 0xD7},
	{REG_Y_ADD_END_MSB, 0x0A},
	{REG_Y_ADD_END_LSB, 0x67},
	{REG_DOL_HDR_EN, 0x01},
	{REG_DOL_HDR_NUM, 0x01},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0A},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x00},
	{REG_BINNING_HV, 0x11},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3C00, 0x00},
	{0x3C01, 0x03},
	{0x3C02, 0xDC},
	{REG_ADC_BIT_SETTING, 0x00},
	{0x5748, 0x07},
	{0x5749, 0xFF},
	{0x574A, 0x00},
	{0x574B, 0x00},
	{0x7B75, 0x0E},
	{0x7B76, 0x09},
	{0x7B77, 0x0C},
	{0x7B78, 0x06},
	{0x7B79, 0x3B},
	{0x7B53, 0x01},
	{0x9369, 0x5A},
	{0x936B, 0x55},
	{0x936D, 0x28},
	{0x9304, 0x03},
	{0x9305, 0x00},
	{0x9E9A, 0x2F},
	{0x9E9B, 0x2F},
	{0x9E9C, 0x2F},
	{0x9E9D, 0x00},
	{0x9E9E, 0x00},
	{0x9E9F, 0x00},
	{0xA2A9, 0x60},
	{0xA2B7, 0x00},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x0F},
	{REG_DIG_CROP_WIDTH_LSB, 0xD8},
	{REG_DIG_CROP_HEIGHT_MSB, 0x08},
	{REG_DIG_CROP_HEIGHT_LSB, 0xF0},
	{REG_X_OUT_SIZE_MSB, 0x0F},
	{REG_X_OUT_SIZE_LSB, 0xD8},
	{REG_Y_OUT_SIZE_MSB, 0x08},
	{REG_Y_OUT_SIZE_LSB, 0xF0},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0xAF},
	{REG_IOPPXCK_DIV, 0x0A},
	{REG_IOPSYCK_DIV, 0x01},
	{REG_IOP_PREPLLCK_DIV, 0x04},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0xC8},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x12},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0xC0},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x87},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x10},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x87},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5F},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x5F},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x10},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x3F},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3F},
	{0xE04C, 0x00},
	{0xE04D, 0x87},
	{0xE04E, 0x00},
	{0xE04F, 0x1F},
	{0x3E20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x00},
	{REG_LINE_LEN_INCLK_LSB, 0xDC},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo sensor_imx477_2X2BIN_2000x1128_60FPS[] = 
{
	/* Line Length PCK Setting */
	{REG_LINE_LEN_MSB, 0x42}, 
	{REG_LINE_LEN_LSB, 0x40}, 
	/* Frame Length Lines Setting */
	{REG_FRAME_LEN_MSB, 0x0B}, 
	{REG_FRAME_LEN_LSB, 0x63}, 
	/*ROI Setting*/
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x02},
	{REG_Y_ADD_STA_LSB, 0xE8},
	{REG_X_ADD_END_MSB, 0x1F},
	{REG_X_ADD_END_LSB, 0x3F},
	{REG_Y_ADD_END_MSB, 0x14},
	{REG_Y_ADD_END_LSB, 0x87},
	/* Mode Setting */
	{REG_BINNING_MODE, 0x01},  /* Binning mode: Enable        */
	{REG_BINNING_HV, 0x22},  /* Binning Type for Horizontal */
	{REG_BINNING_WEIGHTING, 0x08},  /* Binning Type for Vertical   */
	{0x30D8, 0x00},
	{0x3200, 0x41},
	{0x3201, 0x41},
	/*Digital Crop & Scaling*/
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x07},
	{REG_DIG_CROP_WIDTH_LSB, 0xD0},
	{REG_DIG_CROP_HEIGHT_MSB, 0x04},
	{REG_DIG_CROP_HEIGHT_LSB, 0x68},
	/*Output Size Setting*/
	{REG_X_OUT_SIZE_MSB, 0x07},
	{REG_X_OUT_SIZE_LSB, 0xD0},
	{REG_Y_OUT_SIZE_MSB, 0x04},
	{REG_Y_OUT_SIZE_LSB, 0x68},
	/*Clock Setting*/
	{REG_IVTPXCK_DIV, 0x06},
	{REG_IVTSYCK_DIV, 0x04},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x57},
	{REG_IOPPXCK_DIV, 0x0a},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x04},
	{REG_IOP_MPY_MSB, 0x01},
	{REG_IOP_MPY_LSB, 0x49},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{0x0224, 0x01},
	{0x0225, 0xF4},
	{0x3FE0, 0x01},
	{0x3FE1, 0xF4},
	/*Gain Setting*/
	{REG_ANA_GLOBAL_GAIN_U, 0x00},
	{0x0205, 0x70},
	{0x0216, 0x00},
	{0x0217, 0x70},
	{0x0218, 0x01},
	{0x0219, 0x00},
	{0x020E, 0x01},
	{0x020F, 0x00},
	{0x0210, 0x01},
	{0x0211, 0x00},
	{0x0212, 0x01},
	{0x0213, 0x00},
	{0x0214, 0x01},
	{0x0215, 0x00},
	{0x3FE2, 0x00},
	{0x3FE3, 0x70},
	{0x3FE4, 0x01},
	{0x3FE5, 0x00},
	/*PDAF TYPE2 Setting*/
	{0x3E20, 0x01},
	{0x3E3B, 0x00},
	{0x4434, 0x00},
	{0x4435, 0xF8},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};

struct reginfo RESOLUTION1_4056X3040_REGS[] = {
	{REG_LINE_LEN_MSB, 0x5D},
	{REG_LINE_LEN_LSB, 0xC0},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x00},
	{REG_Y_ADD_STA_LSB, 0x00},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},
	{REG_Y_ADD_END_MSB, 0x0B},
	{REG_Y_ADD_END_LSB, 0xDF},
	{REG_DOL_HDR_EN, 0x01},
	{REG_DOL_HDR_NUM, 0x00},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0a},
	{0x3140, 0x02},
	{0x3241, 0x11},
	{0x3250, 0x03},
	{0x3E10, 0x01},//vc:1  li:0
	{0x3E11, 0x02},//vc:2  li:0
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x00},
	{REG_BINNING_HV, 0x11},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x03},
	{0x3c02, 0xa2},
	{REG_ADC_BIT_SETTING, 0x0C},
	{0x5748, 0x07},
	{0x5749, 0xff},
	{0x574a, 0x00},
	{0x574b, 0x00},
	{0x7b75, 0x0a},
	{0x7b76, 0x0c},
	{0x7b77, 0x07},
	{0x7b78, 0x06},
	{0x7b79, 0x3c},
	{0x7b53, 0x01},
	{0x9369, 0x5A},
	{0x936b, 0x55},
	{0x936d, 0x28},
	{0x9304, 0x00},
	{0x9305, 0x00},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x60},
	{0xa2b7, 0x00},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0xd8},
	{REG_DIG_CROP_HEIGHT_MSB, 0x0b},
	{REG_DIG_CROP_HEIGHT_LSB, 0xE0},
	{REG_X_OUT_SIZE_MSB, 0x0F},
	{REG_X_OUT_SIZE_LSB, 0xd8},
	{REG_Y_OUT_SIZE_MSB, 0x0B},
	{REG_Y_OUT_SIZE_LSB, 0xE0},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0x9B},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x85},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x7f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x02},
	{REG_LINE_LEN_INCLK_LSB, 0xAE},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo resolution2_4056x3040_regs[] = {
	{REG_LINE_LEN_MSB, 0x5d},
	{REG_LINE_LEN_LSB, 0xc0},
	{REG_X_ADD_STA_MSB, 0x00},
	{0x0345, 0x00},
	{0x0346, 0x00},
	{0x0347, 0x00},
	{0x0348, 0x0f},
	{0x0349, 0xd7},
	{0x034a, 0x0b},
	{0x034b, 0xdf},
	{REG_DOL_HDR_EN, 0x01},
	{REG_DOL_HDR_NUM, 0x01},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0a},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{0x0385, 0x01},
	{0x0387, 0x01},
	{REG_BINNING_MODE, 0x00},
	{REG_BINNING_HV, 0x11},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x03},
	{0x3c02, 0xa2},
	{REG_ADC_BIT_SETTING, 0x01},
	{0x5748, 0x07},
	{0x5749, 0xff},
	{0x574a, 0x00},
	{0x574b, 0x00},
	{0x7b75, 0x0a},
	{0x7b76, 0x0c},
	{0x7b77, 0x07},
	{0x7b78, 0x06},
	{0x7b79, 0x3c},
	{0x7b53, 0x01},
	{0x9369, 0x5a},
	{0x936b, 0x55},
	{0x936d, 0x28},
	{0x9304, 0x00},
	{0x9305, 0x00},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x60},
	{0xa2b7, 0x00},
	{0x0401, 0x00},
	{0x0404, 0x00},
	{0x0405, 0x10},
	{0x0408, 0x00},
	{0x0409, 0x00},
	{0x040a, 0x00},
	{0x040b, 0x00},
	{0x040c, 0x0f},
	{0x040d, 0xd8},
	{0x040e, 0x0b},
	{0x040f, 0xe0},
	{0x034c, 0x0f},
	{0x034d, 0xd8},
	{0x034e, 0x0b},
	{0x034f, 0xe0},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x5e},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x96},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{0x080a, 0x00},
	{0x080b, 0x7f},
	{0x080c, 0x00},
	{0x080d, 0x4f},
	{0x080e, 0x00},
	{0x080f, 0x77},
	{0x0810, 0x00},
	{0x0811, 0x5f},
	{0x0812, 0x00},
	{0x0813, 0x57},
	{0x0814, 0x00},
	{0x0815, 0x4f},
	{0x0816, 0x01},
	{0x0817, 0x27},
	{0x0818, 0x00},
	{0x0819, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x7f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x02},
	{REG_LINE_LEN_INCLK_LSB, 0xae},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};

struct reginfo resolution3_4056x3040_regs[] = {
	{REG_CSI_FORMAT_C, 0x0A},
	{REG_CSI_FORMAT_D, 0x0A},
	{REG_CSI_LANE, 0x01},
	{REG_LINE_LEN_MSB, 0x11},
	{REG_LINE_LEN_LSB, 0xA0},
	{REG_FRAME_LEN_MSB, 0x0E},
	{REG_FRAME_LEN_LSB, 0x8A},
	{0x3210, 0x00},
	{REG_X_ADD_STA_MSB, 0x00},
	{0x0345, 0x00},
	{0x0346, 0x00},
	{0x0347, 0x00},
	{0x0348, 0x0F},
	{0x0349, 0xD7},
	{0x034A, 0x0B},
	{0x034B, 0xDF},
	{REG_DOL_HDR_EN, 0x01},
	{REG_DOL_HDR_NUM, 0x01},
	{0x00E5, 0x00},//vc:0
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0A},
	{REG_DOL_CONST, 0x01},//vc:1
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x12},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3241, 0x11},
	{0x3250, 0x03},
	{0x3E10, 0x01},//vc:1  li:0
	{0x3E11, 0x02},//vc:2  li:0
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x3F42, 0x00},
	{0x3F43, 0x00},
	{0x0401, 0x00},
	{0x0404, 0x00},
	{0x0405, 0x10},
	{0x0408, 0x00},
	{0x0409, 0x00},
	{0x040A, 0x00},
	{0x040B, 0x00},
	{0x040C, 0x0F},
	{0x040D, 0xD8},
	{0x040E, 0x0B},
	{0x040F, 0xE0},
	{0x034C, 0x0F},
	{0x034D, 0xDC},
	{0x034E, 0x0B},
	{0x034F, 0xE0},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x5E},
	{REG_IOPPXCK_DIV, 0x0A},
	{REG_IOPSYCK_DIV, 0x01},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x01},
	{REG_IOP_MPY_LSB, 0x5E},
	{REG_PLL_MULTI_DRV, 0x00},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x20},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0xD0},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{0x3E20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x00},
	{REG_LINE_LEN_INCLK_LSB, 0x82},
	{0x3C0A, 0x5A},
	{0x3C0B, 0x55},
	{0x3C0C, 0x28},
	{0x3C0D, 0x07},
	{0x3C0E, 0xFF},
	{0x3C0F, 0x00},
	{0x3C10, 0x00},
	{0x3C11, 0x02},
	{0x3C12, 0x00},
	{0x3C13, 0x03},
	{0x3C14, 0x00},
	{0x3C15, 0x00},
	{0x3C16, 0x0C},
	{0x3C17, 0x0C},
	{0x3C18, 0x0C},
	{0x3C19, 0x0A},
	{0x3C1A, 0x0A},
	{0x3C1B, 0x0A},
	{0x3C1C, 0x00},
	{0x3C1D, 0x00},
	{0x3C1E, 0x00},
	{0x3C1F, 0x00},
	{0x3C20, 0x00},
	{0x3C21, 0x00},
	{0x3C22, 0x3F},
	{0x3C23, 0x0A},
	{0x3E35, 0x01},
	{0x3F4A, 0x03},
	{0x3F4B, 0xBF},
	{0x3F26, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB, 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_ANA_GLOBAL_GAIN_U, 0x00},
	{0x0205, 0x00},
	{0x020E, 0x01},
	{0x020F, 0x00},
	{0x0210, 0x01},
	{0x0211, 0x00},
	{0x0212, 0x01},
	{0x0213, 0x00},
	{0x0214, 0x01},
	{0x0215, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};

struct reginfo RESOLUTION4_4056X3040_REGS[] = {
	/* Frame Horizontal Clock Count */
	{0x0342, 0x39}, /* Line length [15:8]  */
	{0x0343, 0x14}, /* Line length [7:0]   */

	/* Frame Vertical Clock Count */
	{0x0340, 0x20}, /* Frame length [15:8] */
	{0x0341, 0x11}, /* Frame length [7:0]  */

	/* Visible Size */
	{0x0344, 0x00}, /* Analog cropping start X [12:8] */
	{0x0345, 0x00}, /* Analog cropping start X [7:0]  */
	{0x0346, 0x00}, /* Analog cropping start Y [12:8] */
	{0x0347, 0x00}, /* Analog cropping start Y [7:0]  */
	{0x0348, 0x0F}, /* Analog cropping end X [12:8]   */
	{0x0349, 0xD7}, /* Analog cropping end X [7:0]    */
	{0x034A, 0x0B}, /* Analog cropping end Y [12:8]   */
	{0x034B, 0xDF}, /* Analog cropping end Y [7:0]    */

	/* Mode Setting */
	{0x00E3, 0x00}, /* DOL-HDR Disable */
	{0x00E4, 0x00}, /* DOL Mode: DOL-HDR Disable */
	{0x0220, 0x00}, /* Undocumented */
	{0x0221, 0x11}, /* Undocumented */
	{0x0381, 0x01}, /* Num of pixels skipped, even -> odd */
	{0x0383, 0x01}, /* Num of pixels skipped, odd -> even */
	{0x0385, 0x01}, /* Num of lines skipped, even -> odd  */
	{0x0387, 0x01}, /* Num of lines skipped, odd -> even  */
	{0x0900, 0x00}, /* Binning mode: Disable */
	{0x0901, 0x11}, /* Binning Type for Horizontal */
	{0x0902, 0x02}, /* Binning Type for Vertical   */
	{0x3140, 0x02}, /* Undocumented */
	{0x3C00, 0x00}, /* Undocumented */
	{0x3C01, 0x03}, /* Undocumented */
	{0x3C02, 0xDC}, /* Undocumented */
	{0x3F0D, 0x00}, /* AD converter: 10 bit */
	{0x5748, 0x07}, /* Undocumented */
	{0x5749, 0xFF}, /* Undocumented */
	{0x574A, 0x00}, /* Undocumented */
	{0x574B, 0x00}, /* Undocumented */
	{0x7B75, 0x0E}, /* Undocumented */
	{0x7B76, 0x09}, /* Undocumented */
	{0x7B77, 0x0C}, /* Undocumented */
	{0x7B78, 0x06}, /* Undocumented */
	{0x7B79, 0x3B}, /* Undocumented */
	{0x7B53, 0x01}, /* Undocumented */
	{0x9369, 0x5A}, /* Undocumented */
	{0x936B, 0x55}, /* Undocumented */
	{0x936D, 0x28}, /* Undocumented */
	{0x9304, 0x03}, /* Undocumented */
	{0x9305, 0x00}, /* Undocumented */
	{0x9E9A, 0x2F}, /* Undocumented */
	{0x9E9B, 0x2F}, /* Undocumented */
	{0x9E9C, 0x2F}, /* Undocumented */
	{0x9E9D, 0x00}, /* Undocumented */
	{0x9E9E, 0x00}, /* Undocumented */
	{0x9E9F, 0x00}, /* Undocumented */
	{0xA2A9, 0x60}, /* Undocumented */
	{0xA2B7, 0x00}, /* Undocumented */

	/* Digital Crop & Scaling */
	{0x0401, 0x00}, /* Scaling mode: No Scaling     */
	{0x0404, 0x00}, /* Down Scaling Factor M [8]    */
	{0x0405, 0x10}, /* Down Scaling Factor M [7:0]  */
	{0x0408, 0x00}, /* Crop Offset from X [12:8]    */
	{0x0409, 0x00}, /* Crop Offset from X [7:0]     */
	{0x040A, 0x00}, /* Crop Offset from Y [12:8]    */
	{0x040B, 0x00}, /* Crop Offset from Y [7:0]     */
	{0x040C, 0x0F}, /* Width after cropping [12:8]  */
	{0x040D, 0xD8}, /* Width after cropping [7:0]   */
	{0x040E, 0x0B}, /* Height after cropping [12:8] */
	{0x040F, 0xE0}, /* Height after cropping [7:0]  */

	/* Output Crop */
	{0x034C, 0x0F}, /* X output size [12:8] */
	{0x034D, 0xD8}, /* X output size [7:0]  */
	{0x034E, 0x0B}, /* Y output size [12:8] */
	{0x034F, 0xE0}, /* Y output size [7:0]  */
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo RESOLUTION_3840X2160_30FPS_REGS[] = {
	{REG_CSI_FORMAT_C, 0x0A},
	{REG_CSI_FORMAT_D, 0x0A},
	{REG_CSI_LANE, 0x01},
	{REG_LINE_LEN_MSB, 0x2B},
	{REG_LINE_LEN_LSB, 0xC0},
	{REG_FRAME_LEN_MSB, 0x09},
	{REG_FRAME_LEN_LSB, 0xC4},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x01},
	{REG_Y_ADD_STA_LSB, 0xB8},
	{REG_X_ADD_END_MSB, 0x0F},
	{REG_X_ADD_END_LSB, 0xD7},
	{REG_Y_ADD_END_MSB, 0x0A},
	{REG_Y_ADD_END_LSB, 0x27},
	{REG_DOL_HDR_EN, 0x00},
	{REG_DOL_HDR_NUM, 0x00},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0A},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x00},
	{REG_BINNING_HV, 0x11},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3C00, 0x00},
	{0x3C01, 0x03},
	{0x3C02, 0xDC},
	{REG_ADC_BIT_SETTING, 0x00},
	{0x5748, 0x07},
	{0x5749, 0xFF},
	{0x574A, 0x00},
	{0x574B, 0x00},
	{0x7B75, 0x0E},
	{0x7B76, 0x09},
	{0x7B77, 0x0C},
	{0x7B78, 0x06},
	{0x7B79, 0x3B},
	{0x7B53, 0x01},
	{0x9369, 0x5A},
	{0x936B, 0x55},
	{0x936D, 0x28},
	{0x9304, 0x03},
	{0x9305, 0x00},
	{0x9E9A, 0x2F},
	{0x9E9B, 0x2F},
	{0x9E9C, 0x2F},
	{0x9E9D, 0x00},
	{0x9E9E, 0x00},
	{0x9E9F, 0x00},
	{0xA2A9, 0x60},
	{0xA2B7, 0x00},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x6C},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x0F},
	{REG_DIG_CROP_WIDTH_LSB, 0x00},
	{REG_DIG_CROP_HEIGHT_MSB, 0x08},
	{REG_DIG_CROP_HEIGHT_LSB, 0x70},
	{REG_X_OUT_SIZE_MSB, 0x0F},
	{REG_X_OUT_SIZE_LSB, 0x00},
	{REG_Y_OUT_SIZE_MSB, 0x08},
	{REG_Y_OUT_SIZE_LSB, 0x70},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0xAF},
	{REG_IOPPXCK_DIV, 0x0A},
	{REG_IOPSYCK_DIV, 0x01},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x7D},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x0B},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0xB8},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x97},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x5F},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x9F},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x6F},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x6F},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x57},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x87},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x4F},
	{0xE04C, 0x00},
	{0xE04D, 0x9F},
	{0xE04E, 0x00},
	{0xE04F, 0x1F},
	{0x3E20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x40},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
    
    
//4x4 binning 10bit
struct reginfo RESOLUTION_640X480_REGS[] = {
	{0x420b, 0x01},
	{0x990c, 0x00},
	{0x990d, 0x08},
	{0x9956, 0x8c},
	{0x9957, 0x64},
	{0x9958, 0x50},
	{0x9a48, 0x06},
	{0x9a49, 0x06},
	{0x9a4a, 0x06},
	{0x9a4b, 0x06},
	{0x9a4c, 0x06},
	{0x9a4d, 0x06},
	{REG_LINE_LEN_MSB, 0x1a},
	{REG_LINE_LEN_LSB, 0x08},
	{REG_FRAME_LEN_MSB, 0x04},
	{REG_FRAME_LEN_LSB, 0x1a},
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},
	{REG_Y_ADD_STA_MSB, 0x02},
	{REG_Y_ADD_STA_LSB, 0x10},
	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0xd7},
	{REG_Y_ADD_END_MSB, 0x09},
	{REG_Y_ADD_END_LSB, 0xcf},
	{REG_DOL_HDR_EN, 0x00},
	{REG_DOL_HDR_NUM, 0x00},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0a},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0a},
	{REG_DOL_CONST, 0x00},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x22},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x01},
	{0x3c02, 0x9c},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x00},
	{0x5749, 0x00},
	{0x574a, 0x00},
	{0x574b, 0xa4},
	{0x7b75, 0x0e},
	{0x7b76, 0x09},
	{0x7b77, 0x08},
	{0x7b78, 0x06},
	{0x7b79, 0x34},
	{0x7b53, 0x00},
	{0x9369, 0x73},
	{0x936b, 0x64},
	{0x936d, 0x5f},
	{0x9304, 0x03},
	{0x9305, 0x80},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x27},
	{0xa2b7, 0x03},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	{REG_DIG_CROP_X_OFFSET_MSB, 0x02},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x5c},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x02},
	{REG_DIG_CROP_WIDTH_LSB, 0x80},
	{REG_DIG_CROP_HEIGHT_MSB, 0x01},
	{REG_DIG_CROP_HEIGHT_LSB, 0xE0},
	{REG_X_OUT_SIZE_MSB, 0x02},
	{REG_X_OUT_SIZE_LSB, 0x80},
	{REG_Y_OUT_SIZE_MSB, 0x01},
	{REG_Y_OUT_SIZE_LSB, 0xE0},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x02},
	{REG_PLL_IVT_MPY_MSB, 0x00},
	{REG_PLL_IVT_MPY_LSB, 0x9B},
	{REG_IOPPXCK_DIV, 0x0a},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x85},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x5f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x00},
	{REG_LINE_LEN_INCLK_LSB, 0xbf},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB , 0x05},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0x00},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo MODE_1_REGS[] = {
	/* Line Length PCK Setting */
	{REG_LINE_LEN_MSB, 0x82}, 
	{REG_LINE_LEN_LSB, 0x40}, 
	{REG_FRAME_LEN_MSB, 0x0B},
	{REG_FRAME_LEN_LSB, 0x63},
	/* ROI Setting */
	{REG_X_ADD_STA_MSB, 0x00}, /*	x_addr_start[15:8]	*/
	{REG_X_ADD_STA_LSB, 0x00}, /*	x_addr_start[7:0]	*/
	{REG_Y_ADD_STA_MSB, 0x03}, /*	y_addr_start[15:8]	*/
	{REG_Y_ADD_STA_LSB, 0x60}, /*	y_addr_start[7:0]	*/
	{REG_X_ADD_END_MSB, 0x24}, /*	x_addr_end[15:8]	*/
	{REG_X_ADD_END_LSB, 0x1F}, /*	x_addr_end[7:0]	*/
	{REG_Y_ADD_END_MSB, 0x17}, /*	y_addr_end[15:8]	*/
	{REG_Y_ADD_END_LSB, 0xBF},  /*	y_addr_end[7:0]	*/
	{REG_DOL_HDR_EN, 0x00},
	{REG_DOL_HDR_NUM, 0x00},
	{REG_DOL_CSI_DT_FMT_H_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_2ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_H_3ND, 0x0A},
	{REG_DOL_CSI_DT_FMT_L_3ND, 0x0A},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x01},
	{REG_BINNING_HV, 0x22},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3C00, 0x00},
	{0x3C01, 0x01},
	{0x3C02, 0x9C},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x00},
	{0x5749, 0x00},
	{0x574A, 0x00},
	{0x574B, 0xA4},
	{0x7B75, 0x0E},
	{0x7B76, 0x09},
	{0x7B77, 0x08},
	{0x7B78, 0x06},
	{0x7B79, 0x34},
	{0x7B53, 0x00},
	{0x9369, 0x73},
	{0x936B, 0x64},
	{0x936D, 0x5F},
	{0x9304, 0x03},
	{0x9305, 0x80},
	{0x9E9A, 0x2F},
	{0x9E9B, 0x2F},
	{0x9E9C, 0x2F},
	{0x9E9D, 0x00},
	{0x9E9E, 0x00},
	{0x9E9F, 0x00},
	{0xA2A9, 0x27},
	{0xA2B7, 0x03},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x10},
	/* Digital Crop & Scaling */
	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_WIDTH_MSB, 0x12},
	{REG_DIG_CROP_WIDTH_LSB, 0x10},
	{REG_DIG_CROP_HEIGHT_MSB, 0x0A},
	{REG_DIG_CROP_HEIGHT_LSB, 0x2C},
	/* Output Size Setting */
	{REG_X_OUT_SIZE_MSB, 0x12},  /*	x_output_size[15:8]	*/
	{REG_X_OUT_SIZE_LSB, 0x10},  /*	x_output_size[7:0]	*/
	{REG_Y_OUT_SIZE_MSB, 0x0A},  /*	y_output_size[15:8]	*/
	{REG_Y_OUT_SIZE_LSB, 0x2C},  /*	y_output_size[7:0]	*/
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x5E},
	{REG_IOPPXCK_DIV, 0x0A},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x03},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0xFA},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x0F},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0xA0},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x77},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x47},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x67},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x57},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x4F},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x3F},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x0F},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x37},
	{0xE04C, 0x00},
	{0xE04D, 0x6F},
	{0xE04E, 0x00},
	{0xE04F, 0x1F},
	{0x3E20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x00},
	{REG_LINE_LEN_INCLK_LSB, 0x5A},
	/* Other Setting */
	{0x30D9, 0x01},
	{0x32D5, 0x00},
	{0x32D6, 0x00},
	{0x401E, 0x00},
	{0x40B8, 0x04},
	{0x40B9, 0xC4},
	{0x40BC, 0x00},
	{0x40BD, 0xB4},
	{0x40BE, 0x00},
	{0x40BF, 0xB4},
	{0x41A4, 0x06},
	{0x5A09, 0x01},
	{0x5A17, 0x01},
	{0x5A25, 0x01},
	{0x5A33, 0x01},
	{0x98D7, 0xB4},
	{0x98D8, 0x8C},
	{0x98D9, 0x0A},
	{0x99C4, 0x16},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
struct reginfo RGB_GAIN_SETTINGS[] = 
{
	/*GAIN SETTING*/
	{REG_MODE_SEL,          0x00},
	{REG_ANA_GLOBAL_GAIN_U, 0x02},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U,     0x01},
	{REG_DIG_GAIN_GR_L,     0x00},
	{REG_DIG_GAIN_R_U,      0x03},
	{REG_DIG_GAIN_R_L,      0x00},
	{REG_DIG_GAIN_B_U,      0x02},
	{REG_DIG_GAIN_B_L ,     0x00},
	{REG_DIG_GAIN_GB_U ,    0x01},
	{REG_DIG_GAIN_GB_L,     0x00},
	{REG_MODE_SEL,          0x00},
	{SEQUENCE_END,          0x00}
};

struct reginfo RGB_COLOR1_SETTINGS[] = 
{
	/*GAIN SETTING*/
	{REG_MODE_SEL,                         0x00},
	/* Startup digital gains from the per-channel UART readback. */
	{REG_DIG_GAIN_GR_U,                    0x05},
	{REG_DIG_GAIN_GR_L,                    0x90},
	{REG_DIG_GAIN_R_U,                     0x07},
	{REG_DIG_GAIN_R_L,                     0xB0},
	{REG_DIG_GAIN_B_U,                     0x07},
	{REG_DIG_GAIN_B_L,                     0xB0},
	{REG_DIG_GAIN_GB_U,                    0x04},
	{REG_DIG_GAIN_GB_L,                    0x00},
	{REG_DIG_GLOBAL_GAIN,                  0x00},
	{REG_ANA_GLOBAL_GAIN_U,                0x02},
	{REG_ANA_GLOBAL_GAIN_L,                0xAB},
	/* Keep the coarse exposure programmed by the selected mode table. */
	{REG_MODE_SEL,                         0x01},
	{SEQUENCE_END,                         0x00}
};
struct reginfo RESOLUTION5_4056X3040_REGS[] =
{
     /* Line Length PCK Setting */
	{REG_LINE_LEN_MSB, 0x5D},
	{REG_LINE_LEN_LSB, 0xC0},
    /* ROI Setting */

    /* X ROI SIZE 0 TO 3840 = 3840*/
	{REG_X_ADD_STA_MSB, 0x00},
	{REG_X_ADD_STA_LSB, 0x00},

	{REG_X_ADD_END_MSB, 0x0f},
	{REG_X_ADD_END_LSB, 0x00},

    /* Y ROI SIZE 0 TO 2271 = 3039*/
	{REG_Y_ADD_STA_MSB, 0x00},
	{REG_Y_ADD_STA_LSB, 0x00},

	{REG_Y_ADD_END_MSB, 0x08},
	{REG_Y_ADD_END_LSB, 0xDF},

    /* X CROP SIZE 3840*/
	{REG_DIG_CROP_WIDTH_MSB, 0x0f},
	{REG_DIG_CROP_WIDTH_LSB, 0x00},

    /* Y CROP SIZE 2160*/
	{REG_DIG_CROP_HEIGHT_MSB, 0x08},
	{REG_DIG_CROP_HEIGHT_LSB, 0x70},

    /* X OUT SIZE 3840*/
	{REG_X_OUT_SIZE_MSB, 0x0F},
	{REG_X_OUT_SIZE_LSB, 0x00},

    /* Y OUT SIZE 2160*/
	{REG_Y_OUT_SIZE_MSB, 0x08},
	{REG_Y_OUT_SIZE_LSB, 0x70},

	{REG_DIG_CROP_X_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_X_OFFSET_LSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_MSB, 0x00},
	{REG_DIG_CROP_Y_OFFSET_LSB, 0x00},


	{0x0220, 0x00},
	{0x0221, 0x11},
	{REG_X_ENV_INC_CONST, 0x01},
	{REG_X_ODD_INC_CONST, 0x01},
	{REG_Y_ENV_INC_CONST, 0x01},
	{REG_Y_ODD_INC, 0x01},
	{REG_BINNING_MODE, 0x00},
	{REG_BINNING_HV, 0x22},
	{REG_BINNING_WEIGHTING, 0x02},
	{0x3140, 0x02},
	{0x3c00, 0x00},
	{0x3c01, 0x03},
	{0x3c02, 0xa2},
	{REG_ADC_BIT_SETTING, 0x0A},
	{0x5748, 0x07},
	{0x5749, 0xff},
	{0x574a, 0x00},
	{0x574b, 0x00},
	{0x7b53, 0x01},
	{0x9369, 0x73},
	{0x936b, 0x64},
	{0x936d, 0x5f},
	{0x9304, 0x00},
	{0x9305, 0x00},
	{0x9e9a, 0x2f},
	{0x9e9b, 0x2f},
	{0x9e9c, 0x2f},
	{0x9e9d, 0x00},
	{0x9e9e, 0x00},
	{0x9e9f, 0x00},
	{0xa2a9, 0x60},
	{0xa2b7, 0x00},
	{REG_SCALE_MODE, 0x00},
	{REG_SCALE_M_MSB, 0x00},
	{REG_SCALE_M_LSB, 0x20},
	{REG_IVTPXCK_DIV, 0x05},
	{REG_IVTSYCK_DIV, 0x02},
	{REG_IVT_PREPLLCK_DIV, 0x04},
	{REG_PLL_IVT_MPY_MSB, 0x01},
	{REG_PLL_IVT_MPY_LSB, 0x5e},
	{REG_IOPPXCK_DIV, 0x0c},
	{REG_IOPSYCK_DIV, 0x02},
	{REG_IOP_PREPLLCK_DIV, 0x02},
	{REG_IOP_MPY_MSB, 0x00},
	{REG_IOP_MPY_LSB, 0x96},
	{REG_PLL_MULTI_DRV, 0x01},
	{REG_REQ_LINK_BIT_RATE_MSB, 0x07},
	{REG_REQ_LINK_BIT_RATE_LMSB, 0x08},
	{REG_REQ_LINK_BIT_RATE_MLSB, 0x00},
	{REG_REQ_LINK_BIT_RATE_LSB, 0x00},
	{REG_TCLK_POST_EX_MSB, 0x00},
	{REG_TCLK_POST_EX_LSB, 0x7f},
	{REG_THS_PRE_EX_MSB, 0x00},
	{REG_THS_PRE_EX_LSB, 0x4f},
	{REG_THS_ZERO_MIN_MSB, 0x00},
	{REG_THS_ZERO_MIN_LSB, 0x77},
	{REG_THS_TRAIL_EX_MSB, 0x00},
	{REG_THS_TRAIL_EX_LSB, 0x5f},
	{REG_TCLK_TRAIL_MIN_MSB, 0x00},
	{REG_TCLK_TRAIL_MIN_LSB, 0x57},
	{REG_TCLK_PREP_EX_MSB, 0x00},
	{REG_TCLK_PREP_EX_LSB, 0x4f},
	{REG_TCLK_ZERO_EX_MSB, 0x01},
	{REG_TCLK_ZERO_EX_LSB, 0x27},
	{REG_TLPX_EX_MSB, 0x00},
	{REG_TLPX_EX_LSB, 0x3f},
	{0xe04c, 0x00},
	{0xe04d, 0x7f},
	{0xe04e, 0x00},
	{0xe04f, 0x1f},
	{0x3e20, 0x01},
	{REG_PDAF_CTRL1_0, 0x00},
	{REG_POWER_SAVE_ENABLE, 0x00},
	{REG_LINE_LEN_INCLK_MSB, 0x01},
	{REG_LINE_LEN_INCLK_LSB, 0x6c},
	{REG_ANA_GLOBAL_GAIN_U, 0x03},
	{REG_ANA_GLOBAL_GAIN_L, 0x7f},
	{REG_DIG_GAIN_GR_U, 0x02},
	{REG_DIG_GAIN_GR_L, 0x00},
	{REG_DIG_GAIN_R_U, 0x03},
	{REG_DIG_GAIN_R_L, 0x00},
	{REG_DIG_GAIN_B_U, 0x02},
	{REG_DIG_GAIN_B_L , 0x00},
	{REG_DIG_GAIN_GB_U , 0x02},
	{REG_DIG_GAIN_GB_L, 0x00},
	/* Verified 4K startup timing and coarse exposure. */
	{REG_FRAME_LEN_MSB, 0x0C},
	{REG_FRAME_LEN_LSB, 0x14},
	{REG_CIT_LSHIFT_LONG_EXP, 0x00},
	{REG_COARSE_INTEGRATION_TIME_MSB, 0x0A},
	{REG_COARSE_INTEGRATION_TIME_LSB, 0xCB},
	{REG_MODE_SEL, 0x01},
	{SEQUENCE_END, 0x00}
};
//struct reginfo RESOLUTION1_4056_2288_19MHZ_DOL_3F_REGS[] = {
//
//	/* Frame Horizontal Clock Count */
//	{REG_LINE_LEN_MSB, 0x5D}, /* Line length [15:8] 0x39  */
//	{REG_LINE_LEN_LSB, 0xC0}, /* Line length [7:0]  0x14   */
//
//	/* Frame Vertical Clock Count */
//	{REG_FRAME_LEN_MSB, 0x42}, /* Frame length [15:8] */
//	{REG_FRAME_LEN_LSB, 0x40}, /* Frame length [7:0]  */
//
//	/* Visible Size */
//	/* (0,376) to (4055, 2664) */
//	{0x0344, 0x00}, /* Analog cropping start X [12:8] */
//	{0x0345, 0x00}, /* Analog cropping start X [7:0]  */
//	{0x0346, 0x01}, /* Analog cropping start Y [12:8] */
//	{0x0347, 0x78}, /* Analog cropping start Y [7:0]  */
//	{0x0348, 0x0F}, /* Analog cropping end X [12:8]   */
//	{0x0349, 0xD7}, /* Analog cropping end X [7:0]    */
//	{0x034A, 0x0A}, /* Analog cropping end Y [12:8]   */
//	{0x034B, 0x68}, /* Analog cropping end Y [7:0]    */
//
//	/* Mode Setting */
//	{0x00E3, 0x01}, /* DOL-HDR Disable */
//	{0x00E4, 0x02}, /* DOL Mode: DOL3*/
//	{0x00FC, 0x0A}, /* The output data fmt for CSI: RAW10 */
//	{0x00FD, 0x0A}, /* The output data fmt for CSI: RAW10 */
//	{0x00FE, 0x0A}, /* The output data fmt for CSI: RAW10 */
//	{0x00FF, 0x0A}, /* The output data fmt for CSI: RAW10 */
//	{0x3E10, 0x01}, /* VC ID of DOL 2nd frame */
//	{0x3E11, 0x02}, /* VC ID of DOL 3rd frame */
//
//	{0x0220, 0x00}, /* Undocumented */
//	{0x0221, 0x11}, /* Undocumented */
//	{0x0381, 0x01}, /* Num of pixels skipped, even -> odd */
//	{0x0383, 0x01}, /* Num of pixels skipped, odd -> even */
//	{0x0385, 0x01}, /* Num of lines skipped, even -> odd  */
//	{0x0387, 0x01}, /* Num of lines skipped, odd -> even  */
//	{0x0900, 0x00}, /* Binning mode: Disable */
//	{0x0901, 0x11}, /* Binning Type for Horizontal */
//	{0x0902, 0x02}, /* Binning Type for Vertical   */
//	{0x3140, 0x02}, /* Undocumented */
//	{0x3C00, 0x00}, /* Undocumented */
//	{0x3C01, 0x03}, /* Undocumented */
//	{0x3C02, 0xDC}, /* Undocumented */
//	{0x3F0D, 0x00}, /* AD converter: 10 bit */
//	{0x5748, 0x07}, /* Undocumented */
//	{0x5749, 0xFF}, /* Undocumented */
//	{0x574A, 0x00}, /* Undocumented */
//	{0x574B, 0x00}, /* Undocumented */
//	{0x7B75, 0x0E}, /* Undocumented */
//	{0x7B76, 0x09}, /* Undocumented */
//	{0x7B77, 0x0C}, /* Undocumented */
//	{0x7B78, 0x06}, /* Undocumented */
//	{0x7B79, 0x3B}, /* Undocumented */
//	{0x7B53, 0x01}, /* Undocumented */
//	{0x9369, 0x5A}, /* Undocumented */
//	{0x936B, 0x55}, /* Undocumented */
//	{0x936D, 0x28}, /* Undocumented */
//	{0x9304, 0x03}, /* Undocumented */
//	{0x9305, 0x00}, /* Undocumented */
//	{0x9E9A, 0x2F}, /* Undocumented */
//	{0x9E9B, 0x2F}, /* Undocumented */
//	{0x9E9C, 0x2F}, /* Undocumented */
//	{0x9E9D, 0x00}, /* Undocumented */
//	{0x9E9E, 0x00}, /* Undocumented */
//	{0x9E9F, 0x00}, /* Undocumented */
//	{0xA2A9, 0x60}, /* Undocumented */
//	{0xA2B7, 0x00}, /* Undocumented */
//
//	/* Digital Crop & Scaling */
//	{0x0401, 0x00}, /* Scaling mode: No Scaling     */
//	{0x0404, 0x00}, /* Down Scaling Factor M [8]    */
//	{0x0405, 0x10}, /* Down Scaling Factor M [7:0]  */
//	{0x0408, 0x00}, /* Crop Offset from X [12:8]    */
//	{0x0409, 0x00}, /* Crop Offset from X [7:0]     */
//	{0x040A, 0x00}, /* Crop Offset from Y [12:8]    */
//	{0x040B, 0x00}, /* Crop Offset from Y [7:0]     */
//	{0x040C, 0x0F}, /* Width after cropping [12:8]  */
//	{0x040D, 0xD8}, /* Width after cropping [7:0]   */
//	{0x040E, 0x08}, /* Height after cropping [12:8] */
//	{0x040F, 0xF0}, /* Height after cropping [7:0]  */
//
//	/* Output Crop */
//	{0x034C, 0x0F}, /* X output size [12:8] */
//	{0x034D, 0xD8}, /* X output size [7:0]  */
//	{0x034E, 0x08}, /* Y output size [12:8] */
//	{0x034F, 0xF0}, /* Y output size [7:0]  */
//	{REG_MODE_SEL, 0x01},
//	{SEQUENCE_END, 0x00}
//};

int imx477_read(XIicPs *IicInstance,u16 addr,u8 *read_buf)
{
	*read_buf=i2c_reg16_read(IicInstance,IIC_IMX477_ADDR,addr);
	return XST_SUCCESS;
}
int imx477_write(XIicPs *IicInstance,u16 addr,u8 data)
{
	return i2c_reg16_write(IicInstance,IIC_IMX477_ADDR,addr,data);
}
void imx_477_sensor_write_array(XIicPs *IicInstance, struct reginfo *regarray)
{
	int i = 0;
	while (regarray[i].reg != SEQUENCE_END) {
		imx477_write(IicInstance,regarray[i].reg,regarray[i].val);
		i++;
	}
}
int imx477_sensor_init(XIicPs *IicInstance,u16 config_number)
{
	u8 sensor_id[2];
    int flag = 0;
    int address = 0;
    while( address < 255 ) {
       address++;
       scan_read(IicInstance, REG_MODEL_ID_MSB, &sensor_id[0],address);
       scan_read(IicInstance, REG_MODEL_ID_LSB, &sensor_id[1],address);
       if(sensor_id[0] == 0x4 || sensor_id[1] == 0x77) {
         //printf("Got IMX477 Camera Sensor ID: x%x\r\n", sensor_id[0], sensor_id[1]);
          flag = 1;
          break;
       }
    }
        imx477_read(IicInstance, REG_MODEL_ID_MSB, &sensor_id[0]);
        imx477_read(IicInstance, REG_MODEL_ID_LSB, &sensor_id[1]);
        if ((sensor_id[0] == 0x7 && sensor_id[1] == 0x7)  || (sensor_id[0] == 0x4 && sensor_id[1] == 0x77))
	{
            printf("Got IMX477 Camera Sensor ID: %x%x\n", sensor_id[0], sensor_id[1]);
            imx_477_sensor_write_array(IicInstance,ONETIME_INIT_REG_SET1);
            usleep(1000000);
            if(config_number < 8) {
            imx_477_sensor_write_array(IicInstance,RGB_GAIN_SETTINGS);
            }
//            if(config_number == 0) {
//              imx_477_sensor_write_array(IicInstance,ONETIME_INIT_REG_SET1);
//          } else if (config_number == 1) {
//              imx_477_sensor_write_array(IicInstance,ONETIME_INIT_REG_SET2);
//          } else if (config_number == 2) {
//              imx_477_sensor_write_array(IicInstance,ONETIME_INIT_REG_SET3);
            if (config_number == 3) {
                imx_477_sensor_write_array(IicInstance,RESOLUTION1_1920X1080_REGS);
                imx_477_sensor_write_array(IicInstance,RGB_COLOR1_SETTINGS);
            } else if (config_number == 4) {
                imx_477_sensor_write_array(IicInstance,RESOLUTION2_1920X1080_REGS);
                imx_477_sensor_write_array(IicInstance,RGB_COLOR1_SETTINGS);
            } else if (config_number == 5) {
                imx_477_sensor_write_array(IicInstance,RESOLUTION_640X480_REGS);
//            } else if (config_number == 6) {
//                imx_477_sensor_write_array(IicInstance,MODE_1_REGS);
//            } else if (config_number == 7) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION1_4056X3040_REGS);
//            } else if (config_number == 8) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION_3840X2160_30FPS_REGS);
//            } else if (config_number == 9) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION3_1920X1080_REGS);
//            } else if (config_number == 10) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION_1332X990_REGS);
//            } else if (config_number == 11) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION_2028X1080_REGS);
//            } else if (config_number == 12) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION_2028X1520_REGS);
//            } else if (config_number == 13) {
//                imx_477_sensor_write_array(IicInstance,RESOLUTION4_4056X3040_REGS);
            } else {
                imx_477_sensor_write_array(IicInstance,RESOLUTION5_4056X3040_REGS);
                imx_477_sensor_write_array(IicInstance,RGB_COLOR1_SETTINGS);
            }
            return 477;
    }
	
}
int imx477_read_register(XIicPs *IicInstance,u16 addr)
{
	u8 sensor_id[1];
    imx477_read(IicInstance, addr, &sensor_id[0]);
    printf("Read IMX477 Read Reg Address  =  %x   Value = %x\n",addr,sensor_id[0]);
	return 0;
}
int imx477_write_register(XIicPs *IicInstance,u16 addr,u8 data)
{
	imx477_write(IicInstance,REG_MODE_SEL, 0x00);
	imx477_write(IicInstance,addr,data);
	imx477_write(IicInstance,REG_MODE_SEL, 0x01);
    printf("Read IMX477 Write Reg Address  =  %x   Value = %x\n",addr,data);
	return 0;
}
int imx477_write_read_register(XIicPs *IicInstance,u16 addr,u8 data)
{
	imx477_write_register(IicInstance,addr,data);
	imx477_read_register(IicInstance,addr);
	return 0;
}


static int tuning_wait_idle(XIicPs *iic)
{
    for (unsigned int elapsed = 0; elapsed < 200; ++elapsed) {
        if (!XIicPs_BusIsBusy(iic))
            return IMX477_TUNING_OK;
        usleep(10);
    }
    return IMX477_TUNING_IO_ERROR;
}

static int tuning_recover_bus(XIicPs *iic)
{
    XIicPs_ClearOptions(iic, XIICPS_REP_START_OPTION);
    XIicPs_Abort(iic);
    if (XIicPs_SetSClk(iic, 100000U) != XST_SUCCESS)
        return IMX477_TUNING_IO_ERROR;
    return tuning_wait_idle(iic);
}

static int tuning_read_transfer(XIicPs *iic, u16 device, u16 reg,
                                u8 *data, int repeated_start)
{
    u8 address[] = {(u8)(reg >> 8), (u8)reg};

    for (unsigned int attempt = 0; attempt < 2; ++attempt) {
        if (tuning_wait_idle(iic) == IMX477_TUNING_OK) {
            int result;

            usleep(100);
            if (repeated_start)
                XIicPs_SetOptions(iic, XIICPS_REP_START_OPTION);
            result = XIicPs_MasterSendPolled(iic, address, sizeof(address), device);
            XIicPs_ClearOptions(iic, XIICPS_REP_START_OPTION);
            if (result == XST_SUCCESS &&
                XIicPs_MasterRecvPolled(iic, data, 1, device) == XST_SUCCESS &&
                tuning_wait_idle(iic) == IMX477_TUNING_OK)
                return IMX477_TUNING_OK;
        }

        if (tuning_recover_bus(iic) != IMX477_TUNING_OK) {
            printf("IMX477 I2C recovery failed at 0x%04X.\r\n", (unsigned)reg);
            break;
        }
    }
    return IMX477_TUNING_IO_ERROR;
}

static int tuning_read_at(XIicPs *iic, u16 device, u16 reg, u8 *data)
{
    return tuning_read_transfer(iic, device, reg, data, 1);
}

static u16 tuning_device;

static int tuning_identify(XIicPs *iic)
{
    static const u16 candidates[] = {0x1A, 0x10};

    tuning_device = 0;
    for (unsigned int i = 0; i < sizeof(candidates) / sizeof(candidates[0]); ++i) {
        u8 high, low;
        u16 device = candidates[i];

        if (tuning_read_at(iic, device, REG_MODEL_ID_MSB, &high) != IMX477_TUNING_OK ||
            tuning_read_at(iic, device, REG_MODEL_ID_LSB, &low) != IMX477_TUNING_OK) {
            printf("IMX477 probe at 0x%02X: chip ID read failed.\r\n", (unsigned)device);
            continue;
        }
        if ((((u16)high << 8) | low) == IMX477_CHIP_ID) {
            tuning_device = device;
            return IMX477_TUNING_OK;
        }
        printf("IMX477 probe at 0x%02X: chip ID %02X %02X (expected 04 77).\r\n",
               (unsigned)device, (unsigned)high, (unsigned)low);
    }
    return IMX477_TUNING_IO_ERROR;
}

void imx477_tuning_diagnose(XIicPs *iic)
{
    static const u16 registers[] = {
        REG_MODEL_ID_MSB, REG_MODEL_ID_LSB, REG_MODE_SEL,
        REG_FRAME_LEN_MSB, REG_FRAME_LEN_LSB,
        REG_LINE_LEN_MSB, REG_LINE_LEN_LSB,
        REG_X_OUT_SIZE_MSB, REG_X_OUT_SIZE_LSB,
        REG_Y_OUT_SIZE_MSB, REG_Y_OUT_SIZE_LSB,
        REG_COARSE_INTEGRATION_TIME_MSB, REG_COARSE_INTEGRATION_TIME_LSB,
        REG_ANA_GLOBAL_GAIN_U, REG_ANA_GLOBAL_GAIN_L
    };

    if (tuning_identify(iic) != IMX477_TUNING_OK)
        return;

    printf("IMX477 I2C 0x%02X | register | repeated START | STOP then START\r\n",
           (unsigned)tuning_device);
    for (unsigned int i = 0; i < sizeof(registers) / sizeof(registers[0]); ++i) {
        u8 repeated_value = 0, stop_value = 0;
        int repeated_status = tuning_read_transfer(iic, tuning_device, registers[i],
                                                   &repeated_value, 1);
        int stop_status = tuning_read_transfer(iic, tuning_device, registers[i],
                                               &stop_value, 0);

        printf("0x%04X | ", (unsigned)registers[i]);
        if (repeated_status == IMX477_TUNING_OK)
            printf("%02X", (unsigned)repeated_value);
        else
            printf("ERR");
        printf(" | ");
        if (stop_status == IMX477_TUNING_OK)
            printf("%02X\r\n", (unsigned)stop_value);
        else
            printf("ERR\r\n");
    }
}

static int tuning_read(XIicPs *iic, u16 reg, u8 *data)
{
    int result = tuning_read_at(iic, tuning_device, reg, data);

    if (result != IMX477_TUNING_OK)
        printf("IMX477 read failed at 0x%04X (device 0x%02X).\r\n",
               (unsigned)reg, (unsigned)tuning_device);
    return result;
}

static int tuning_read_u16(XIicPs *iic, u16 reg, u16 *value)
{
    u8 high, low;

    if (tuning_read(iic, reg, &high) != IMX477_TUNING_OK ||
        tuning_read(iic, reg + 1, &low) != IMX477_TUNING_OK)
        return IMX477_TUNING_IO_ERROR;
    *value = ((u16)high << 8) | low;
    return IMX477_TUNING_OK;
}

static int tuning_write_byte(XIicPs *iic, u16 reg, u8 value)
{
    u8 bytes[] = {(u8)(reg >> 8), (u8)reg, value};

    if (tuning_wait_idle(iic) == IMX477_TUNING_OK &&
        XIicPs_MasterSendPolled(iic, bytes, sizeof(bytes), tuning_device) == XST_SUCCESS &&
        tuning_wait_idle(iic) == IMX477_TUNING_OK)
        return IMX477_TUNING_OK;

    tuning_recover_bus(iic);
    printf("IMX477 write failed at 0x%04X (data 0x%02X)\r\n",
           (unsigned)reg, (unsigned)value);
    return IMX477_TUNING_IO_ERROR;
}

static int tuning_check_timing(XIicPs *iic, u16 *frame_lines)
{
    u16 output_lines;

    if (tuning_read_u16(iic, REG_FRAME_LEN_MSB, frame_lines) != IMX477_TUNING_OK ||
        tuning_read_u16(iic, REG_Y_OUT_SIZE_MSB, &output_lines) != IMX477_TUNING_OK)
        return IMX477_TUNING_IO_ERROR;
    if (output_lines != VIDEO1_ROWS || *frame_lines < output_lines) {
        printf("IMX477 invalid timing readback: frame %u lines, output %u lines (expected output %u).\r\n",
               (unsigned)*frame_lines, (unsigned)output_lines, (unsigned)VIDEO1_ROWS);
        return IMX477_TUNING_RANGE_ERROR;
    }
    return IMX477_TUNING_OK;
}

static int tuning_write_register(XIicPs *iic, u16 reg, u16 value, int wide)
{
    u16 previous, actual, frame_before, frame_after;
    u8 mode, byte;
    int result;

    result = tuning_check_timing(iic, &frame_before);
    if (result != IMX477_TUNING_OK)
        return result;

    if (tuning_read(iic, REG_MODE_SEL, &mode) != IMX477_TUNING_OK ||
        (wide ? tuning_read_u16(iic, reg, &previous) : tuning_read(iic, reg, &byte))
            != IMX477_TUNING_OK)
        return IMX477_TUNING_IO_ERROR;

    if (!wide)
        previous = byte;
    result = tuning_write_byte(iic, REG_MODE_SEL, IMX477_MODE_STANDBY);
    if (result == IMX477_TUNING_OK) {
        result = tuning_write_byte(iic, reg, (u8)(wide ? value >> 8 : value));
        if (result == IMX477_TUNING_OK && wide)
            result = tuning_write_byte(iic, reg + 1, (u8)value);
        if (result == IMX477_TUNING_OK) {
            if (wide) {
                result = tuning_read_u16(iic, reg, &actual);
            } else {
                result = tuning_read(iic, reg, &byte);
                actual = byte;
            }
            if (result == IMX477_TUNING_OK && actual != value) {
                printf("IMX477 readback 0x%04X at 0x%04X, expected 0x%04X\r\n",
                       (unsigned)actual, (unsigned)reg, (unsigned)value);
                result = IMX477_TUNING_IO_ERROR;
            }
        }
        if (result == IMX477_TUNING_OK) {
            result = tuning_read_u16(iic, REG_FRAME_LEN_MSB, &frame_after);
            if (result == IMX477_TUNING_OK && frame_after != (reg == REG_FRAME_LEN_MSB ? value : frame_before)) {
                printf("IMX477 unexpected frame-length change: %u to %u lines.\r\n",
                       (unsigned)frame_before, (unsigned)frame_after);
                result = IMX477_TUNING_IO_ERROR;
            }
        }
        if (result != IMX477_TUNING_OK) {
            tuning_write_byte(iic, reg, (u8)(wide ? previous >> 8 : previous));
            if (wide)
                tuning_write_byte(iic, reg + 1, (u8)previous);
        }
    }

    if (tuning_write_byte(iic, REG_MODE_SEL, mode) != IMX477_TUNING_OK) {
        printf("IMX477 failed to restore its stream mode.\r\n");
        return IMX477_TUNING_IO_ERROR;
    }
    return result;
}

int imx477_tuning_read(XIicPs *iic, Imx477TuningStatus *status)
{
    int result = tuning_identify(iic);

    if (result != IMX477_TUNING_OK)
        return result;
    result = tuning_check_timing(iic, &status->frame_lines);
    if (result != IMX477_TUNING_OK)
        return result;
    if (tuning_read_u16(iic, REG_COARSE_INTEGRATION_TIME_MSB,
                        &status->exposure_lines) != IMX477_TUNING_OK ||
        tuning_read_u16(iic, REG_ANA_GLOBAL_GAIN_U,
                        &status->analog_gain_code) != IMX477_TUNING_OK ||
        tuning_read(iic, REG_CIT_LSHIFT_LONG_EXP, &status->long_exposure_shift) != IMX477_TUNING_OK ||
        tuning_read(iic, REG_DOL_HDR_EN, &status->dol_enable) != IMX477_TUNING_OK ||
        tuning_read(iic, REG_DOL_HDR_NUM, &status->dol_mode) != IMX477_TUNING_OK)
        return IMX477_TUNING_IO_ERROR;
    status->i2c_address = (u8)tuning_device;
    return IMX477_TUNING_OK;
}

int imx477_tuning_exposure(XIicPs *iic, unsigned int preset)
{
    static const u8 percentages[] = {5, 15, 35, 60, 90};
    Imx477TuningStatus status;
    unsigned int max_lines;
    unsigned int lines;
    int result;

    if (preset >= sizeof(percentages) / sizeof(percentages[0]))
        return IMX477_TUNING_RANGE_ERROR;
    result = imx477_tuning_read(iic, &status);
    if (result != IMX477_TUNING_OK)
        return result;
    if (status.dol_enable & 1U)
        return IMX477_TUNING_HDR_ACTIVE;
    if (status.frame_lines < IMX477_EXPOSURE_MIN + IMX477_EXPOSURE_OFFSET)
        return IMX477_TUNING_RANGE_ERROR;

    max_lines = status.frame_lines - IMX477_EXPOSURE_OFFSET;
    lines = max_lines * percentages[preset] / 100U;
    if (lines < IMX477_EXPOSURE_MIN)
        lines = IMX477_EXPOSURE_MIN;
    return tuning_write_register(iic, REG_COARSE_INTEGRATION_TIME_MSB, (u16)lines, 1);
}

int imx477_tuning_brightness(XIicPs *iic, unsigned int preset)
{
    static const u16 gain_codes[] = {0, 341, 512, 683, 768};
    Imx477TuningStatus status;
    int result;

    if (preset >= sizeof(gain_codes) / sizeof(gain_codes[0]))
        return IMX477_TUNING_RANGE_ERROR;
    result = imx477_tuning_read(iic, &status);
    if (result != IMX477_TUNING_OK)
        return result;
    if (status.dol_enable & 1U)
        return IMX477_TUNING_HDR_ACTIVE;
    return tuning_write_register(iic, REG_ANA_GLOBAL_GAIN_U, gain_codes[preset], 1);
}

/* CSI-2 RX 0 AXI-Lite base in the KV260 zusys block design. */
#define IMX477_CSI_RX_BASE 0xA0000000U

static void tuning_print_csi_rx(const char *label)
{
    u32 core = Xil_In32(IMX477_CSI_RX_BASE + 0x10U);
    u32 irq = Xil_In32(IMX477_CSI_RX_BASE + 0x24U);

    printf("%s: long packets %u, core 0x%08X, ISR 0x%08X\r\n",
           label, (unsigned)(core >> 16), (unsigned)core, (unsigned)irq);
    for (unsigned int vc = 0; vc < 4; ++vc) {
        u32 info1 = Xil_In32(IMX477_CSI_RX_BASE + 0x60U + 8U * vc);
        u32 info2 = Xil_In32(IMX477_CSI_RX_BASE + 0x64U + 8U * vc);

        printf("VC%u: image info 1 0x%08X, last data type 0x%02X\r\n",
               vc, (unsigned)info1, (unsigned)(info2 & 0x3fU));
    }
}

int imx477_dol_probe(XIicPs *iic)
{
    /* Snapshot the affected registers so manual SDR tuning survives the probe. */
    u8 saved[sizeof(sensor_4k_regs) / sizeof(sensor_4k_regs[0])];
    Imx477TuningStatus status;
    u8 stream_mode, enabled, mode;
    unsigned int index;
    int result = imx477_tuning_read(iic, &status);
    int restore_result = IMX477_TUNING_OK;

    if (result != IMX477_TUNING_OK)
        return result;
    if (status.dol_enable & 1U)
        return IMX477_TUNING_HDR_ACTIVE;
    if (tuning_read(iic, REG_MODE_SEL, &stream_mode) != IMX477_TUNING_OK ||
        stream_mode != IMX477_MODE_STREAMING)
        return IMX477_TUNING_IO_ERROR;

    for (index = 0; sensor_4k_regs[index].reg != SEQUENCE_END; ++index) {
        u16 reg = sensor_4k_regs[index].reg;

        if (reg != REG_MODE_SEL && reg != REG_DLY &&
            tuning_read(iic, reg, &saved[index]) != IMX477_TUNING_OK)
            return IMX477_TUNING_IO_ERROR;
    }

    tuning_print_csi_rx("SDR baseline");
    result = tuning_write_byte(iic, REG_MODE_SEL, IMX477_MODE_STANDBY);
    if (result == IMX477_TUNING_OK)
        usleep(32000);
    for (index = 0; result == IMX477_TUNING_OK &&
                    sensor_4k_regs[index].reg != SEQUENCE_END; ++index) {
        u16 reg = sensor_4k_regs[index].reg;

        if (reg != REG_MODE_SEL && reg != REG_DLY)
            result = tuning_write_byte(iic, reg, sensor_4k_regs[index].val);
    }
    if (result == IMX477_TUNING_OK)
        result = tuning_write_byte(iic, REG_MODE_SEL, IMX477_MODE_STREAMING);
    if (result == IMX477_TUNING_OK) {
        usleep(100000);
        if (tuning_read(iic, REG_DOL_HDR_EN, &enabled) != IMX477_TUNING_OK ||
            tuning_read(iic, REG_DOL_HDR_NUM, &mode) != IMX477_TUNING_OK ||
            enabled != 1 || mode != 1) {
            printf("DOL mode readback failed.\r\n");
            result = IMX477_TUNING_IO_ERROR;
        } else {
            tuning_print_csi_rx("DOL sample 1");
            usleep(100000);
            tuning_print_csi_rx("DOL sample 2");
        }
    }

    if (tuning_write_byte(iic, REG_MODE_SEL, IMX477_MODE_STANDBY) != IMX477_TUNING_OK) {
        printf("DOL probe could not stop the sensor for SDR restore. Reboot the board.\r\n");
        return IMX477_TUNING_IO_ERROR;
    }
    usleep(32000);
    while (index > 0) {
        u16 reg = sensor_4k_regs[--index].reg;

        if (reg != REG_MODE_SEL && reg != REG_DLY &&
            tuning_write_byte(iic, reg, saved[index]) != IMX477_TUNING_OK)
            restore_result = IMX477_TUNING_IO_ERROR;
    }
    if (restore_result != IMX477_TUNING_OK ||
        tuning_write_byte(iic, REG_MODE_SEL, stream_mode) != IMX477_TUNING_OK) {
        printf("SDR restore failed. Reboot the board.\r\n");
        return IMX477_TUNING_IO_ERROR;
    }
    if (imx477_tuning_read(iic, &status) != IMX477_TUNING_OK || status.dol_enable & 1U) {
        printf("SDR restore could not be verified. Reboot the board.\r\n");
        return IMX477_TUNING_IO_ERROR;
    }
    printf("SDR timing restored.\r\n");
    return result;
}

static const u16 digital_gain_registers[] = {
    REG_DIG_GAIN_GR_U, REG_DIG_GAIN_R_U, REG_DIG_GAIN_B_U, REG_DIG_GAIN_GB_U
};

int imx477_digital_gain_read(XIicPs *iic, u16 gains[4], u8 *global)
{
    int result = tuning_identify(iic);

    if (result != IMX477_TUNING_OK)
        return result;
    if (tuning_read(iic, REG_DIG_GLOBAL_GAIN, global) != IMX477_TUNING_OK)
        return IMX477_TUNING_IO_ERROR;
    for (unsigned int channel = 0; channel < 4; ++channel) {
        if (tuning_read_u16(iic, digital_gain_registers[channel], &gains[channel])
            != IMX477_TUNING_OK)
            return IMX477_TUNING_IO_ERROR;
    }
    return IMX477_TUNING_OK;
}

int imx477_digital_gain_set(XIicPs *iic, unsigned int channel, u16 gain)
{
    Imx477TuningStatus status;
    int result;

    /* Channel 4 selects the global-gain control byte. */
    if (channel > 4 || (channel == 4 && gain > 1) ||
        (channel < 4 && gain < 0x0100))
        return IMX477_TUNING_RANGE_ERROR;
    result = imx477_tuning_read(iic, &status);
    if (result != IMX477_TUNING_OK)
        return result;
    if (status.dol_enable & 1U)
        return IMX477_TUNING_HDR_ACTIVE;
    if (channel == 4) {
        u8 global;

        result = tuning_read(iic, REG_DIG_GLOBAL_GAIN, &global);
        if (result != IMX477_TUNING_OK)
            return result;
        return tuning_write_register(iic, REG_DIG_GLOBAL_GAIN,
                                     (global & ~1U) | gain, 0);
    }
    return tuning_write_register(iic, digital_gain_registers[channel], gain, 1);
}

int imx477_video_timing(XIicPs *iic, u16 *width, u16 *height, u16 *frame_lines)
{
    Imx477TuningStatus status;
    int result = imx477_tuning_read(iic, &status);

    if (result != IMX477_TUNING_OK)
        return result;
    if (tuning_read_u16(iic, REG_X_OUT_SIZE_MSB, width) != IMX477_TUNING_OK ||
        tuning_read_u16(iic, REG_Y_OUT_SIZE_MSB, height) != IMX477_TUNING_OK)
        return IMX477_TUNING_IO_ERROR;
    *frame_lines = status.frame_lines;
    return IMX477_TUNING_OK;
}

int imx477_video_set_frame_lines(XIicPs *iic, u16 frame_lines)
{
    Imx477TuningStatus status;
    int result = imx477_tuning_read(iic, &status);

    if (result != IMX477_TUNING_OK)
        return result;
    if ((status.dol_enable & 1U) || status.long_exposure_shift != 0)
        return IMX477_TUNING_HDR_ACTIVE;
    if (frame_lines < VIDEO1_ROWS + 48U || frame_lines > IMX477_FRAME_LENGTH_MAX)
        return IMX477_TUNING_RANGE_ERROR;
    if (status.exposure_lines > frame_lines - IMX477_EXPOSURE_OFFSET) {
        result = tuning_write_register(iic, REG_COARSE_INTEGRATION_TIME_MSB,
                                       frame_lines - IMX477_EXPOSURE_OFFSET, 1);
        if (result != IMX477_TUNING_OK)
            return result;
        result = tuning_write_register(iic, REG_FRAME_LEN_MSB, frame_lines, 1);
        if (result != IMX477_TUNING_OK &&
            tuning_write_register(iic, REG_COARSE_INTEGRATION_TIME_MSB,
                                  status.exposure_lines, 1) != IMX477_TUNING_OK)
            printf("Could not restore the previous exposure.\r\n");
        return result;
    }
    return tuning_write_register(iic, REG_FRAME_LEN_MSB, frame_lines, 1);
}
