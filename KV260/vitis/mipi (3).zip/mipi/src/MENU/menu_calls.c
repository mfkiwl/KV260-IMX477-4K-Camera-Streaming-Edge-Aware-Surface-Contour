#include "menu_calls.h"
#include <stdio.h>
#include <xiicps.h>
#include <xil_printf.h>
#include <xstatus.h>
#include "string.h"
#include "ff.h"
#include "../UART/uartio.h"
#include "../LWIP/lwip_app.h"
#include "config_defines.h"
#include "../SENSORS_CONFIG/init_camera.h"
#include "../SENSORS_CONFIG/IMX477/imx477.h"
#include "../config.h"
#define MAX_STRING_LENGTH 80
static FIL fil;
static FATFS fatfs;
static char *SD_File;
u8 photobufs[VIDEO2_MAX_FRAME];
/* Values from the output selector in vfp_v1_0.vhd. */
enum {
    FILTER_BYPASS = VFP_PREVIEW_BYPASS,
    FILTER_TEST_PATTERN = 1,
    FILTER_DARK_CCM = 6,
    FILTER_COLOR_CLUSTER = 9,
    FILTER_CONTRAST = 13,
    FILTER_SOBEL = 15,
    FILTER_CLUSTER_WITH_EDGES = 16
};

#define FILTER_DEFAULT_LUT 5
#define FILTER_DEFAULT_THRESHOLD 100

struct filter_settings {
    unsigned int preview;
    unsigned int lut;
    unsigned int threshold;
    unsigned int pattern;
};

static const struct filter_settings startup_filters = {
    1, FILTER_DEFAULT_LUT, FILTER_DEFAULT_THRESHOLD, 0
};

static const struct {
    const char *name;
    unsigned int output;
} filter_previews[] = {
    {"Bypass (demosaiced camera)", FILTER_BYPASS},
    {"Dark color correction", FILTER_DARK_CCM},
    {"RGB contrast", FILTER_CONTRAST},
    {"Color clustering", FILTER_COLOR_CLUSTER},
    {"Sobel edges", FILTER_SOBEL},
    {"Color clustering with edges", FILTER_CLUSTER_WITH_EDGES},
    {"Test pattern", FILTER_TEST_PATTERN}
};

#define FILTER_PREVIEW_COUNT (sizeof(filter_previews) / sizeof(filter_previews[0]))

static unsigned int filter_adjust(unsigned int value, unsigned int max,
                                  unsigned int step, int increase)
{
    if (increase)
        return max - value < step ? max : value + step;
    return value < step ? 0 : value - step;
}

static void filter_apply(const struct filter_settings *settings)
{
    unsigned int output = filter_previews[settings->preview].output;

    if (output == FILTER_COLOR_CLUSTER || output == FILTER_CLUSTER_WITH_EDGES)
        per_write_reg(VFP_CENTROID_LUT_SELECT, settings->lut);
    /* The pattern selector and Sobel threshold share this PL register. */
    if (output == FILTER_TEST_PATTERN)
        per_write_reg(VFP_TEST_PATTERN_SELECT_SOBEL_THRESHOLD, settings->pattern);
    else if (output == FILTER_SOBEL || output == FILTER_CLUSTER_WITH_EDGES)
        per_write_reg(VFP_TEST_PATTERN_SELECT_SOBEL_THRESHOLD, settings->threshold);
    per_write_reg(VFP_OUTPUT_CHANNEL_SELECT, output);
}

static void filter_menu(struct filter_settings *settings, unsigned int startup_preview)
{
    printf("\r\nLive VFP filters\r\n");
    for (unsigned int i = 0; i < FILTER_PREVIEW_COUNT; ++i)
        printf("  %u  %s\r\n", i + 1, filter_previews[i].name);
    printf("Left/Right or A/D  Browse previews\r\n"
           "Up/Down or W/S     Adjust the selected filter\r\n"
           "R                  Restore startup filter settings\r\n"
           "Q                  Return to main menu and keep preview\r\n");
    for (;;) {
        unsigned int output = filter_previews[settings->preview].output;
        unsigned int key;

        printf("\r\nSelected preview: %s", filter_previews[settings->preview].name);
        if (output == FILTER_COLOR_CLUSTER || output == FILTER_CLUSTER_WITH_EDGES)
            printf(" | centroid LUT %u%s", settings->lut,
                   output == FILTER_COLOR_CLUSTER ? " (0-7, 9)" : " (adjust in preview 4)");
        if (output == FILTER_SOBEL || output == FILTER_CLUSTER_WITH_EDGES)
            printf(" | Sobel threshold %u (step 10)", settings->threshold);
        if (output == FILTER_TEST_PATTERN)
            printf(" | pattern %u", settings->pattern);
        printf("\r\n> ");
        fflush(stdout);

        key = keypress_to_uart(UART_BASEADDR);
        if (key == 'Q')
            return;
        if (key == '\r' || key == '\n')
            continue;
        if (key == 'R') {
            *settings = startup_filters;
            settings->preview = startup_preview;
            per_write_reg(VFP_CENTROID_LUT_SELECT, settings->lut);
            per_write_reg(VFP_TEST_PATTERN_SELECT_SOBEL_THRESHOLD, settings->threshold);
        } else if (key >= 1 && key <= FILTER_PREVIEW_COUNT) {
            settings->preview = key - 1;
        } else if (key == 'A' || key == KEYPRESS_ARROW_LEFT - 10) {
            settings->preview = (settings->preview + FILTER_PREVIEW_COUNT - 1)
                              % FILTER_PREVIEW_COUNT;
        } else if (key == 'D' || key == KEYPRESS_ARROW_RIGHT - 10) {
            settings->preview = (settings->preview + 1) % FILTER_PREVIEW_COUNT;
        } else if (key == 'W' || key == 'S' || key == KEYPRESS_ARROW_UP - 10
                   || key == KEYPRESS_ARROW_DOWN - 10) {
            int increase = key == 'W' || key == KEYPRESS_ARROW_UP - 10;

            if (output == FILTER_COLOR_CLUSTER) {
                settings->lut = filter_adjust(settings->lut, 9, 1, increase);
                if (settings->lut == 8)
                    settings->lut = increase ? 9 : 7;
            } else if (output == FILTER_SOBEL || output == FILTER_CLUSTER_WITH_EDGES) {
                settings->threshold = filter_adjust(settings->threshold, 65535, 10, increase);
            } else if (output == FILTER_TEST_PATTERN) {
                settings->pattern = filter_adjust(settings->pattern, 21, 1, increase);
            } else {
                printf("This preview has no adjustable value.\r\n");
                continue;
            }
        } else {
            printf("Use 1-7, the arrow keys, W/A/S/D, R, or Q.\r\n");
            continue;
        }
        filter_apply(settings);
    }
}

static void imx477_digital_gain_menu(XIicPs *iic)
{
    static const char *const names[] = {"Gr", "R", "B", "Gb"};
    unsigned int channel = 0;
    u16 gains[4];
    u8 global;

    printf("\r\nIMX477 digital gain (single keys)\r\n"
           "1 Gr   2 Red   3 Blue   4 Gb\r\n"
           "+/- Adjust by 1/16x   U Set selected gain to 1x\r\n"
           "G Global mode   C Per-channel mode   R Readback   Q Back\r\n");

    for (;;) {
        int key;
        int result = imx477_digital_gain_read(iic, gains, &global);

        if (result == IMX477_TUNING_OK)
            printf("Gr %04X  R %04X  B %04X  Gb %04X  0x3FF9=%02X (%s)\r\n",
                   (unsigned)gains[0], (unsigned)gains[1], (unsigned)gains[2],
                   (unsigned)gains[3], (unsigned)global,
                   global & 1U ? "global, uses Gr" : "per-channel");
        else
            printf("Digital gain read failed. Press R to retry.\r\n");

        printf("Digital gain [%s]> ", names[channel]);
        fflush(stdout);
        key = keypress_to_uart(UART_BASEADDR);
        if (key == 'Q')
            return;
        if (key >= 1 && key <= 4) {
            channel = key - 1;
            continue;
        }
        if (key == 'R' || key == '\r' || key == '\n')
            continue;
        if (result != IMX477_TUNING_OK)
            continue;

        if (key == 'G' || key == 'C') {
            result = imx477_digital_gain_set(iic, 4, key == 'G');
        } else if (key == '+' || key == '-' || key == 'U') {
            unsigned int value = gains[channel];

            if (global & 1U && channel != 0) {
                printf("Global mode uses Gr. Select 1 or press C for per-channel gain.\r\n");
                continue;
            }
            if (key == 'U')
                value = 0x0100;
            else if (key == '+')
                value = value <= 0xffef ? value + 0x10 : 0xffff;
            else
                value = value >= 0x0110 ? value - 0x10 : 0x0100;
            if (value < 0x0100)
                value = 0x0100;
            result = imx477_digital_gain_set(iic, channel, (u16)value);
        } else {
            printf("Use 1-4, +, -, U, G, C, R, or Q.\r\n");
            continue;
        }

        if (result == IMX477_TUNING_HDR_ACTIVE)
            printf("Digital gain tuning is available in SDR mode.\r\n");
        else if (result != IMX477_TUNING_OK)
            printf("Digital gain update failed. Check register readback.\r\n");
    }
}

static void imx477_video_mode_menu(XIicPs *iic)
{
    static u16 baseline_lines;
    u16 width, height, lines;

    if (imx477_video_timing(iic, &width, &height, &lines) != IMX477_TUNING_OK) {
        printf("Cannot read IMX477 video timing.\r\n");
        return;
    }
    if (baseline_lines == 0)
        baseline_lines = lines;

    printf("\r\nIMX477 video mode: %ux%u (resolution set by build)\r\n"
           "Sensor frame rate: 1 Original   2 Half   3 One-third   4 Quarter\r\n"
           "R Read timing   Q Back\r\n"
           "DisplayPort refresh is configured separately.\r\n",
           (unsigned)width, (unsigned)height);
    for (;;) {
        unsigned int key;
        unsigned int requested;

        printf("Video mode> ");
        fflush(stdout);
        key = keypress_to_uart(UART_BASEADDR);
        if (key == 'Q')
            return;
        if (key >= 1 && key <= 4) {
            requested = (unsigned int)baseline_lines * key;
            if (requested > 0xffdcU ||
                imx477_video_set_frame_lines(iic, (u16)requested) != IMX477_TUNING_OK) {
                printf("Sensor frame-rate update failed. Check SDR timing and exposure.\r\n");
                continue;
            }
        } else if (key != 'R') {
            continue;
        }

        if (imx477_video_timing(iic, &width, &height, &lines) == IMX477_TUNING_OK)
            printf("%ux%u, %u lines/frame, sensor rate %u%% of original\r\n",
                   (unsigned)width, (unsigned)height, (unsigned)lines,
                   (unsigned)baseline_lines * 100U / lines);
        else
            printf("IMX477 timing readback failed.\r\n");
    }
}

static void imx477_tuning_menu(void)
{
    extern XIicPs iic_cam;

    printf("\r\nIMX477 sensor tuning (single keys)\r\n"
           "1-5  Exposure: 5, 15, 35, 60, or 90%% of usable frame lines\r\n"
           "6-9, 0  Brightness: analog gain codes 0, 341, 512, 683, 768\r\n"
           "H  DOL HDR status   R  Read settings   D  I2C diagnostics   Q  Main menu\r\n"
           "V  Video mode   G  Digital gain   P  Brief DOL CSI-2 probe (restores SDR)\r\n");

    for (;;) {
        int key;
        int result;
        Imx477TuningStatus status;

        printf("IMX477> ");
        fflush(stdout);
        key = keypress_to_uart(UART_BASEADDR);
        if (key == 'Q')
            return;
        if (key == '\r' || key == '\n')
            continue;

        if (key == 'V') {
            imx477_video_mode_menu(&iic_cam);
            continue;
        }
        if (key == 'G') {
            imx477_digital_gain_menu(&iic_cam);
            continue;
        }
        if (key == 'P') {
            if (imx477_dol_probe(&iic_cam) != IMX477_TUNING_OK)
                printf("DOL probe did not complete.\r\n");
            continue;
        }
        if (key == 'D') {
            imx477_tuning_diagnose(&iic_cam);
            continue;
        }
        if (key >= 1 && key <= 5) {
            result = imx477_tuning_exposure(&iic_cam, key - 1);
        } else if ((key >= 6 && key <= 9) || key == 0) {
            result = imx477_tuning_brightness(&iic_cam, key == 0 ? 4 : key - 6);
        } else if (key == 'H' || key == 'R') {
            result = IMX477_TUNING_OK;
        } else {
            printf("Use 1-9, 0, H, R, D, G, P, V, or Q.\r\n");
            continue;
        }

        if (result == IMX477_TUNING_OK)
            result = imx477_tuning_read(&iic_cam, &status);

        if (result == IMX477_TUNING_HDR_ACTIVE) {
            printf("DOL is active. These presets apply to single-exposure modes.\r\n");
        } else if (result == IMX477_TUNING_RANGE_ERROR) {
            printf("IMX477 timing validation failed. Press D for raw I2C readback.\r\n");
        } else if (result != IMX477_TUNING_OK) {
            printf("IMX477 I2C transaction or readback failed. Press R to retry status.\r\n");
        } else if (key == 'H') {
            printf("DOL enable 0x%02X, mode 0x%02X. Switching needs a matched "
                   "sensor and FPGA capture mode.\r\n",
                   (unsigned)status.dol_enable, (unsigned)status.dol_mode);
        } else {
            printf("I2C 0x%02X, exposure %u lines, frame %u lines, shift %u, analog gain %u, DOL %s\r\n",
                   (unsigned)status.i2c_address,
                   (unsigned)status.exposure_lines, (unsigned)status.frame_lines,
                   (unsigned)status.long_exposure_shift, (unsigned)status.analog_gain_code,
                   status.dol_enable & 1U ? "enabled" : "disabled");
        }
    }
}

void menu_calls(int ON_OFF,char *head_buf, char *data_buf, u32 stride,int connected_camera) {
    int menu_calls_enable = ON_OFF;
    unsigned int uart_io;
    u32 current_state = mainmenu;
    unsigned int startup_preview = connected_camera == 477 ? 0 : startup_filters.preview;
    struct filter_settings filters = startup_filters;
    filters.preview = startup_preview;
    u32 k_number;
    u32 k_number_value;

	FRESULT rc;
	char PhotoName[40];
        //per_write_reg(VFP_OUTPUT_CHANNEL_SELECT,0);
        //per_write_reg(VFP_DARK_CCM_PRESET_SELECT,0);
        //per_write_reg(VFP_CENTROID_LUT_WRITE_INDEX,2);

    	per_write_reg(VFP_DARK_CCM_PRESET_SELECT,3);
    	per_write_reg(VFP_LIGHT_CCM_PRESET_SELECT,15);
    	per_write_reg(VFP_BALANCE_CCM_PRESET_SELECT,3);
        per_write_reg(VFP_CENTROID_LUT_WRITE_INDEX,221);
        per_write_reg(VFP_OUTPUT_CHANNEL_SELECT, filter_previews[startup_preview].output);
        per_write_reg(VFP_SOBEL_CLUSTER_INPUT_SELECT,23);
        //per_write_reg(VFP_FRAME_DIMENSIONS,0);
        per_write_reg(VFP_CENTROID_LUT_SELECT, FILTER_DEFAULT_LUT);
        per_write_reg(VFP_TEST_PATTERN_SELECT_SOBEL_THRESHOLD, FILTER_DEFAULT_THRESHOLD);
//        per_write_reg(VFP_UNUSED_31,0);
//        per_write_reg(VFP_UNUSED_32,0);
//        per_write_reg(VFP_UNUSED_33,170);
//        per_write_reg(VFP_UNUSED_34,341);
//        per_write_reg(VFP_UNUSED_35,512);
//        per_write_reg(VFP_UNUSED_36,341);
//        per_write_reg(VFP_UNUSED_37,170);
//        per_write_reg(VFP_UNUSED_38,341);
//        per_write_reg(VFP_UNUSED_39,853);
//        per_write_reg(VFP_UNUSED_40,682);
//        per_write_reg(VFP_UNUSED_41,170);
//        per_write_reg(VFP_UNUSED_42,341);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,1,240,200,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,2,240,180,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,3,230,180,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,4,230,170,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,5,230,160,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,6,230,180,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,7,200,160,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,8,200,150,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,9,200,140,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,10,200,130,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,11,200,200,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,12,160,160,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,13,140,140,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,14,120,120,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,15,100,100,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,16,160,120,70);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,17,160,110,50);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,18,160,100,40);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,19,160,90,30);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,20,160,80,20);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,21,160,70,10);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,22,140,100,40);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,23,140,100,30);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,24,140,100,20);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,25,140,100,10);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,26,120,80,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,27,120,70,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,28,100,90,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,29,100,80,0);
//        per_write_reg_3values(VFP_CENTROID_LUT_DATA,30,100,70,0);
    if(connected_camera == 219){
        per_write_reg(VFP_FRAME_DIMENSIONS,5);
        current_state = lwip;
    }
    if(connected_camera == 519){
        per_write_reg(VFP_FRAME_DIMENSIONS,0);
        current_state = lwip;
    }
    if(connected_camera == 477){

        current_state = imx477s1;
    }
    if(connected_camera == 682){
        per_write_reg(VFP_FRAME_DIMENSIONS,4);
        per_write_reg(VFP_CENTROID_LUT_WRITE_INDEX,8);
        per_write_reg(VFP_DARK_CCM_K1,5000);
        per_write_reg(VFP_DARK_CCM_K2,0);
        per_write_reg(VFP_DARK_CCM_K3,0);
        per_write_reg(VFP_DARK_CCM_K4,0);
        per_write_reg(VFP_DARK_CCM_K5,5000);
        per_write_reg(VFP_DARK_CCM_K6,0);
        per_write_reg(VFP_DARK_CCM_K7,0);
        per_write_reg(VFP_DARK_CCM_K8,0);
        per_write_reg(VFP_DARK_CCM_K9,2500);
        per_write_reg(VFP_DARK_CCM_PRESET_SELECT,15);
        current_state = lwip;
    }
    while (menu_calls_enable == TRUE)
    {
        lwip_stream_poll();
        switch (current_state)
        {
        case mainmenu:
            cmds_menu();
            printf("f + Enter   Live video filters\r\n"
                   "lwip + Enter   Start UDP video and return to this menu\r\n"
                   "j + Enter   Send one 4K JPEG to UDP port 8081\r\n"
                   "k + Enter   Start or stop continuous 4K JPEG over UDP 8081\r\n");
            if (connected_camera == 477)
                printf("t + Enter   IMX477 exposure, brightness, and DOL status\r\n");
            current_state = menu_select;
            break;
        case menu_select:
            uart_io = uart_prompt_io();
            if (uart_io == 0) {
                uart_Red_Text();
                printf("Unknown command entered %x\r\n",(unsigned) uart_io);
                printf("\r>>");
                uart_Default_Text();
                break;
            } else {
                uart_Default_Text();
                current_state = uart_io;
                break;
            }
            break;
        case 't':
        case 'T':
            if (connected_camera == 477)
                imx477_tuning_menu();
            else
                printf("IMX477 tuning requires the IMX477 camera.\r\n");
            current_state = mainmenu;
            break;
        case 'f':
        case 'F':
            filter_menu(&filters, startup_preview);
            current_state = mainmenu;
            break;
        case clear:
            menu_cls();
            current_state = mainmenu;break;
        case kernal:
            printf("Enter k_number\n");
            menu_print_prompt();
            k_number = uart_prompt_io()*4;
            if (k_number == VFP_UNUSED_00)
            {
                printf("Enter K Number Value\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                per_write_reg(k_number,k_number_value);
                printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
                printf("K2 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))+1) & 0x0000ffff);
                printf("K3 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))+1) & 0x0000ffff);
                printf("K4 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))+1) & 0x0000ffff);
                printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
                printf("K6 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))+1) & 0x0000ffff);
                printf("K7 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))+1) & 0x0000ffff);
                printf("K8 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))+1) & 0x0000ffff);
                printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
                current_state = kernal;break;
            }
            else if (k_number == VFP_DARK_CCM_K1 ||
                     k_number == VFP_DARK_CCM_K5 ||
                     k_number == VFP_DARK_CCM_K9 ||
                     k_number == VFP_UNUSED_10 ||
                     k_number == VFP_DARK_CCM_PRESET_SELECT ||
                     k_number == VFP_LIGHT_CCM_PRESET_SELECT ||
                     k_number == VFP_BALANCE_CCM_PRESET_SELECT ||
                     k_number == VFP_RGB_CHANNEL_SELECT ||
                     k_number == VFP_CENTROID_LUT_WRITE_INDEX ||
                     k_number == VFP_OUTPUT_CHANNEL_SELECT ||
                     k_number == VFP_SOBEL_CLUSTER_INPUT_SELECT ||
                     k_number == VFP_UNUSED_18 ||
                     k_number == VFP_FRAME_DIMENSIONS)
            {
                printf("Enter K Number Value\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                per_write_reg(k_number,k_number_value);
                printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
                printf("K2 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))+1) & 0x0000ffff);
                printf("K3 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))+1) & 0x0000ffff);
                printf("K4 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))+1) & 0x0000ffff);
                printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
                printf("K6 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))+1) & 0x0000ffff);
                printf("K7 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))+1) & 0x0000ffff);
                printf("K8 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))+1) & 0x0000ffff);
                printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
                current_state = kernal;break;
            }
            else if (k_number == VFP_DARK_CCM_K2 ||
                     k_number == VFP_DARK_CCM_K3 ||
                     k_number == VFP_DARK_CCM_K4 ||
                     k_number == VFP_DARK_CCM_K6 ||
                     k_number == VFP_DARK_CCM_K7 ||
                     k_number == VFP_DARK_CCM_K8)
            {
                printf("Enter K Number Value\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                per_write_reg(k_number,(~k_number_value)+1);
                printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
                printf("K2 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))+1) & 0x0000ffff);
                printf("K3 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))+1) & 0x0000ffff);
                printf("K4 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))+1) & 0x0000ffff);
                printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
                printf("K6 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))+1) & 0x0000ffff);
                printf("K7 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))+1) & 0x0000ffff);
                printf("K8 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))+1) & 0x0000ffff);
                printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
                current_state = kernal;break;
            }
            else if (k_number/4 == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
                printf("Enter Wrong Register Value\n");
            	current_state = kernal;break;
            }
        case kernal12:
            printf("Enter k_number\n");
            menu_print_prompt();
            k_number = uart_prompt_io()*4;
            if (k_number == VFP_UNUSED_00)
            {
                printf("Enter K Number Value\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                per_write_reg(k_number,k_number_value);
                printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
                printf("K2 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))) & 0x0000ffff);
                printf("K3 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))) & 0x0000ffff);
                printf("K4 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))) & 0x0000ffff);
                printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
                printf("K6 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))) & 0x0000ffff);
                printf("K7 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))) & 0x0000ffff);
                printf("K8 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))) & 0x0000ffff);
                printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
                current_state = kernal12;break;
            }
            else if (k_number == VFP_DARK_CCM_K1 ||
                     k_number == VFP_DARK_CCM_K5 ||
                     k_number == VFP_DARK_CCM_K9 ||
                     k_number == VFP_UNUSED_10 ||
                     k_number == VFP_DARK_CCM_PRESET_SELECT ||
                     k_number == VFP_LIGHT_CCM_PRESET_SELECT ||
                     k_number == VFP_BALANCE_CCM_PRESET_SELECT ||
                     k_number == VFP_RGB_CHANNEL_SELECT ||
                     k_number == VFP_CENTROID_LUT_WRITE_INDEX ||
                     k_number == VFP_OUTPUT_CHANNEL_SELECT ||
                     k_number == VFP_SOBEL_CLUSTER_INPUT_SELECT ||
                     k_number == VFP_UNUSED_18 ||
                     k_number == VFP_FRAME_DIMENSIONS ||
                     k_number == VFP_CENTROID_LUT_READ_INDEX ||
                     k_number == VFP_IMAGE_ADJUST_SELECTOR_VALUE ||
                     k_number == VFP_UNUSED_22 ||
                     k_number == VFP_UNUSED_23 ||
                     k_number == VFP_UNUSED_24 ||
                     k_number == VFP_UNUSED_25 ||
                     k_number == VFP_UNUSED_26 ||
                     k_number == VFP_UNUSED_27 ||
                     k_number == VFP_UNUSED_28 ||
                     k_number == VFP_UNUSED_29 ||
                     k_number == VFP_UNUSED_30 ||
                     k_number == VFP_UNUSED_31 ||
                     k_number == VFP_UNUSED_32 ||
                     k_number == VFP_UNUSED_33 ||
                     k_number == VFP_UNUSED_34 ||
                     k_number == VFP_UNUSED_35 ||
                     k_number == VFP_UNUSED_36 ||
                     k_number == VFP_UNUSED_37 ||
                     k_number == VFP_UNUSED_38 ||
                     k_number == VFP_UNUSED_39 ||
                     k_number == VFP_UNUSED_40 ||
                     k_number == VFP_UNUSED_41 ||
                     k_number == VFP_UNUSED_42 ||
                     k_number == VFP_CENTROID_LUT_SELECT ||
                     k_number == VFP_TEST_PATTERN_SELECT_SOBEL_THRESHOLD)
            {
                printf("Enter K Number Value\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                per_write_reg(k_number,k_number_value);
                printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
                printf("K2 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))+1) & 0x0000ffff);
                printf("K3 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))+1) & 0x0000ffff);
                printf("K4 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))+1) & 0x0000ffff);
                printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
                printf("K6 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))+1) & 0x0000ffff);
                printf("K7 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))+1) & 0x0000ffff);
                printf("K8 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))+1) & 0x0000ffff);
                printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
                current_state = kernal12;break;
            }
            else if (k_number == VFP_DARK_CCM_K2 ||
                     k_number == VFP_DARK_CCM_K3 ||
                     k_number == VFP_DARK_CCM_K4 ||
                     k_number == VFP_DARK_CCM_K6 ||
                     k_number == VFP_DARK_CCM_K7 ||
                     k_number == VFP_DARK_CCM_K8)
            {
                printf("Enter K Number Value\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                per_write_reg(k_number,(k_number_value));
                printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
                printf("K2 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))) & 0x0000ffff);
                printf("K3 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))) & 0x0000ffff);
                printf("K4 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))) & 0x0000ffff);
                printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
                printf("K6 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))) & 0x0000ffff);
                printf("K7 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))) & 0x0000ffff);
                printf("K8 = -%i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))) & 0x0000ffff);
                printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
                current_state = kernal12;break;
            }
            else if (k_number/4 == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
                printf("Enter Wrong Register Value\n");
            	current_state = kernal12;break;
            }
        case imx477c1:
            per_write_reg(VFP_DARK_CCM_K1,5000);       // 5000
            per_write_reg(VFP_DARK_CCM_K2,~500+1);     // -500
            per_write_reg(VFP_DARK_CCM_K3,~500+1);     // -500
            per_write_reg(VFP_DARK_CCM_K4,~500+1);     // -500
            per_write_reg(VFP_DARK_CCM_K5,8000);       // 8000
            per_write_reg(VFP_DARK_CCM_K6,~500+1);     // -500
            per_write_reg(VFP_DARK_CCM_K7,0);          // 0
            per_write_reg(VFP_DARK_CCM_K8,0);          // 0
            per_write_reg(VFP_DARK_CCM_K9,2000);       // 2000
            printf("K1 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K1))) & 0x0000ffff);
            printf("K2 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K2))+1) & 0x0000ffff);
            printf("K3 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K3))+1) & 0x0000ffff);
            printf("K4 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K4))+1) & 0x0000ffff);
            printf("K5 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K5))) & 0x0000ffff);
            printf("K6 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K6))+1) & 0x0000ffff);
            printf("K7 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K7))+1) & 0x0000ffff);
            printf("K8 = -%i \n", (~(D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K8))+1) & 0x0000ffff);
            printf("K9 =  %i \n", ((D5M_mReadReg(XPAR_PS_VIDEO_RX_VIDEO_VFP_0_VFPCONFIG_BASEADDR,VFP_DARK_CCM_K9))) & 0x0000ffff);
            current_state = mainmenu;break;
        case readpixels:
        	fetch_rgb_data();
            current_state = mainmenu;break;
        case 'j':
        case 'J': {
            int status = lwip_jpeg_request();
            printf("%s\r\n", status == 0 ? "4K JPEG queued." :
                   status > 0 ? "JPEG already pending or continuous mode active." : "Ethernet initialization failed.");
            current_state = mainmenu;
            break;
        }
        case 'k':
        case 'K': {
            int status = lwip_mjpeg_toggle();
            printf("%s\r\n", status == 1 ? "Continuous 4K JPEG started." :
                   status == 0 ? "Continuous 4K JPEG stopped after current frame." :
                   status == -2 ? "JPEG pending. Try again after it sends." :
                   "Ethernet initialization failed.");
            current_state = mainmenu;
            break;
        }
        case lwip: {
            int status = lwip_stream_start();

            if (status == 0)
                printf("UDP video enabled. Use f + Enter for live filters.\r\n");
            else if (status > 0)
                printf("UDP video is already enabled.\r\n");
            else
                printf("UDP video failed to start.\r\n");
            current_state = mainmenu;
            break;
        }
        case pics:
            rc = f_mount(&fatfs, "1:/", 0);
            if (rc != FR_OK)
            {
                return;
            }
            printf("Enter file name with extension\n");
            menu_print_prompt();
            char FileName[MAX_STRING_LENGTH] = { 0 };
            char_to_uart(FileName);
            SD_File  = (char *)FileName;
            sprintf(PhotoName, "1:/%s.BMP", SD_File);
            memcpy(&photobufs,data_buf,VIDEO2_MAX_FRAME);
        	bmp_write(PhotoName,head_buf,(char *)&photobufs,stride,&fil);
            current_state = mainmenu;break;
        case imx477wr:
            printf("Enter imx477 Register Address.\n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	printf("Enter imx477 Register Data for the Register.\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                write_imx477_reg(k_number,k_number_value);
            	current_state = imx477wr;break;
            }
        case imx477rd:
            printf("Enter imx477 Register Address \n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	read_imx477_reg(k_number);
            	current_state = imx477rd;break;
            }
        case imx519wr:
            printf("Enter imx519 Register Address.\n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	printf("Enter imx519 Register Data for the Register.\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                write_imx519_reg(k_number,k_number_value);
            	current_state = imx519wr;break;
            }
        case imx519rd:
            printf("Enter imx519 Register Address \n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	read_imx519_reg(k_number);
            	current_state = imx519rd;break;
            }
        case imx219wr:
            printf("Enter imx219 Register Address.\n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	printf("Enter imx219 Register Data for the Register.\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                write_imx219_reg(k_number,k_number_value);
            	current_state = imx219wr;break;
            }
        case imx219rd:
            printf("Enter imx219 Register Address \n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	read_imx219_reg(k_number);
            	current_state = imx219rd;break;
            }
        case imx682wr:
            printf("Enter imx682 Register Address.\n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	printf("Enter imx682 Register Data for the Register.\n");
                menu_print_prompt();
                k_number_value = uart_prompt_io();
                write_imx682_reg(k_number,k_number_value);
            	current_state = imx682wr;break;
            }
        case imx682rd:
            printf("Enter imx682 Register Address \n");
            menu_print_prompt();
            k_number = uart_prompt_io();
            if (k_number == quit)
            {
                printf("Entered Quit\n");
                current_state = mainmenu;break;
            }
            else
            {
            	read_imx682_reg(k_number);
            	current_state = imx682rd;break;
            }
        case imx477s1:
//            printf("Settings For IMX477 Senesor\n");
            per_write_reg(VFP_LIGHT_CCM_K1,1000);
            per_write_reg(VFP_LIGHT_CCM_K2,0);
            per_write_reg(VFP_LIGHT_CCM_K3,0);
            per_write_reg(VFP_LIGHT_CCM_K4,0);
            per_write_reg(VFP_LIGHT_CCM_K5,1500);
            per_write_reg(VFP_LIGHT_CCM_K6,0);
            per_write_reg(VFP_LIGHT_CCM_K7,0);
            per_write_reg(VFP_LIGHT_CCM_K8,0);
            per_write_reg(VFP_LIGHT_CCM_K9,900);
//            per_write_reg(VFP_DARK_CCM_PRESET_SELECT,15);
//            per_write_reg(VFP_CENTROID_LUT_WRITE_INDEX,8);
//            per_write_reg(VFP_FRAME_DIMENSIONS,4);
            //k_number = 3;
            //read_imx477_reg(k_number);
            current_state = mainmenu;break;
        case quit:
            menu_calls_enable = FALSE;
            break;
        case cmds_uart:
            uartvalue();
            current_state =uartcmd(mainmenu,cmds_uart);
            break;
        default:
            printf("\r\n");
            current_state = mainmenu;
            break;
        }
    }
    printf("Break\r\n");
    //menu_calls_enable = TRUE;
}
